//
//  QRCodeViewController.m
//  ApeTools
//
//  Created by 王亚坤 on 2019/3/2.
//  Copyright © 2019 王亚坤. All rights reserved.
//

#import "QRCodeViewController.h"

@interface QRCodeViewController ()

@end

@implementation QRCodeViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    [self setTopTitle:@"QRCode"];
    [self setBackBtnHide:NO];
    [self.view addSubview:self.tab];
}
-(UITextView *)textV1
{
    if (!_textV1)
    {
        _textV1 = [[UITextView alloc]initWithFrame:CGRectMake(FitX(20), FitHeight(20), FitWidth(710), FitHeight(375))];
        _textV1.layer.borderWidth = 1.0f;
        _textV1.layer.borderColor = [UIColor blackColor].CGColor;
        _textV1.delegate = self;
    }
    return _textV1;
}

-(UIImageView *)imageV1
{
    if (!_imageV1)
    {
        _imageV1 = [[UIImageView alloc]initWithFrame:CGRectMake(FitX(20), FitHeight(20)+self.textV1.frame.size.height+FitHeight(150), FitWidth(710), FitHeight(710))];
        _imageV1.layer.borderWidth = 1.0f;
        _imageV1.layer.borderColor = [UIColor blackColor].CGColor;
        //添加点击手势
        UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(doTap)];
        // 允许用户交互
        _imageV1.userInteractionEnabled = YES;
        
        [_imageV1 addGestureRecognizer:tap];

    }
    return _imageV1;
}

-(UITableView *)tab{
    if (!_tab)
    {
        _tab = [[UITableView alloc]initWithFrame:CGRectMake(0,TopAndSystemHeight, ScreenWidth, ScreenHeight-TopAndSystemHeight)];
        _tab.delegate = self;
        _tab.dataSource = self;
    }
    return _tab;
}
-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return 1;
}
-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    UITableViewCell * cell = [tableView dequeueReusableCellWithIdentifier:@"cellid"];
    if (!cell)
    {
        cell = [[UITableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"cellid"];
        [cell addSubview:self.textV1];
        [cell addSubview:self.imageV1];
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
        
        UIButton * btnL = [self createBtn:CGRectMake(FitX(170), FitY(445), FitWidth(180), FitHeight(50)) title:@"识别二维码" iconImage:nil backgroundImage:nil tag:6000 textColor:[UIColor whiteColor]];
        
        
        if ([[[ViewManager shareInstance] getPreferredLanguage] isEqualToString:@"zh-Hans-CN"])
        {
            [btnL setTitle:@"读取二维码" forState:UIControlStateNormal];
        }
        else
        {
            [btnL setTitle:@"Read QR code" forState:UIControlStateNormal];
        }
        
        
        [btnL setBackgroundColor:MainColor];
        btnL.layer.cornerRadius = 5.0f;
        [btnL addTarget:self action:@selector(btnLAction) forControlEvents:UIControlEventTouchUpInside];
        [cell addSubview:btnL];
        
        UIImageView * imagUP = [[UIImageView alloc]initWithFrame:CGRectMake(FitX(355), FitY(438), FitWidth(17), FitHeight(65))];
        imagUP.image = [UIImage imageNamed:@"箭头上"];
        [cell addSubview:imagUP];
        
        UIImageView * imagDOWN = [[UIImageView alloc]initWithFrame:CGRectMake(FitX(378), FitY(438), FitWidth(17), FitHeight(65))];
        imagDOWN.image = [UIImage imageNamed:@"箭头下"];
        [cell addSubview:imagDOWN];
        
        UIButton * btnR = [self createBtn:CGRectMake(FitX(400), FitY(445), FitWidth(180), FitHeight(50)) title:@"生成二维码" iconImage:nil backgroundImage:nil tag:6000 textColor:[UIColor whiteColor]];
        
        
        if ([[[ViewManager shareInstance] getPreferredLanguage] isEqualToString:@"zh-Hans-CN"])
        {
            [btnR setTitle:@"生成二维码" forState:UIControlStateNormal];
        }
        else
        {
            [btnR setTitle:@"Get QR code" forState:UIControlStateNormal];
        }
        
        
        [btnR setBackgroundColor:MainColor];
        btnR.layer.cornerRadius = 5.0f;
        [btnR addTarget:self action:@selector(btnRAction) forControlEvents:UIControlEventTouchUpInside];
        [cell addSubview:btnR];
        
        UIButton * saveBtn = [self createBtn:CGRectMake(FitX(200), FitY(1305), FitWidth(150), FitHeight(50)) title:@"保存" iconImage:nil backgroundImage:nil tag:6020 textColor:[UIColor whiteColor]];
        
        
        if ([[[ViewManager shareInstance] getPreferredLanguage] isEqualToString:@"zh-Hans-CN"])
        {
            [saveBtn setTitle:@"保存" forState:UIControlStateNormal];
        }
        else
        {
            [saveBtn setTitle:@"Save" forState:UIControlStateNormal];
        }
        
        
        [saveBtn setBackgroundColor:MainColor];
        saveBtn.layer.cornerRadius = 5.0f;
        [saveBtn addTarget:self action:@selector(saveBtnAction) forControlEvents:UIControlEventTouchUpInside];
        [cell addSubview:saveBtn];
        
        UIButton * shareBtn = [self createBtn:CGRectMake(FitX(400), FitY(1305), FitWidth(150), FitHeight(50)) title:@"分享" iconImage:nil backgroundImage:nil tag:6020 textColor:[UIColor whiteColor]];
        
        if ([[[ViewManager shareInstance] getPreferredLanguage] isEqualToString:@"zh-Hans-CN"])
        {
            [shareBtn setTitle:@"分享" forState:UIControlStateNormal];
        }
        else
        {
            [shareBtn setTitle:@"Share" forState:UIControlStateNormal];
        }
        
        
        
        [shareBtn setBackgroundColor:MainColor];
        shareBtn.layer.cornerRadius = 5.0f;
        [shareBtn addTarget:self action:@selector(shareBtnAction) forControlEvents:UIControlEventTouchUpInside];
        [cell addSubview:shareBtn];
        
    }
    return cell;
}
-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return (FitHeight(750)*2)*1.2;
}

-(void)btnLAction
{
    
    CIDetector *detector=[CIDetector detectorOfType:CIDetectorTypeQRCode context:nil options:@{CIDetectorAccuracy:CIDetectorAccuracyHigh}];
    
    //转成CIImage
    CIImage *ciimage=[CIImage imageWithCGImage:self.imageV1.image.CGImage];
    
    //检测结果
    NSArray *features =[detector featuresInImage:ciimage];
    CIQRCodeFeature *feature=[features firstObject];
    
    //打印
   self.textV1.text = [feature messageString];

}
-(void)btnRAction
{
    [MyProgressHUD show];
//    1.1 创建用于生成二维码滤镜
        CIFilter *qrFilter = [CIFilter filterWithName:@"CIQRCodeGenerator"];
       NSData *messageData = [_textV1.text dataUsingEncoding:NSUTF8StringEncoding];
    //  1.2 设置二维滤镜的输入
         [qrFilter setValue:messageData forKey:@"inputMessage"];
     //  1.3取出图片
         CIImage *ciImage = qrFilter.outputImage;
     //  1.4 放大图片
         ciImage = [ciImage imageByApplyingTransform:CGAffineTransformMakeScale(8, 8)];
    // 6.此时生成的还是CIImage，可以通过下面方式生成一个固定大小的UIImage
    CGFloat size = 600;
    CGRect extent = CGRectIntegral(ciImage.extent);
    CGFloat scale = MIN(size/CGRectGetWidth(extent), size/CGRectGetHeight(extent));
    // 7.创建bitmap;
    size_t width = CGRectGetWidth(extent) * scale;
    size_t height = CGRectGetHeight(extent) * scale;
    CGColorSpaceRef cs = CGColorSpaceCreateDeviceGray();
    CGContextRef bitmapRef = CGBitmapContextCreate(nil, width, height, 8, 0, cs, (CGBitmapInfo)kCGImageAlphaNone);
    CIContext *context = [CIContext contextWithOptions:nil];
    CGImageRef bitmapImage = [context createCGImage:ciImage fromRect:extent];
    CGContextSetInterpolationQuality(bitmapRef, kCGInterpolationNone);
    CGContextScaleCTM(bitmapRef, scale, scale);
    CGContextDrawImage(bitmapRef, extent, bitmapImage);
    
    // 8.保存bitmap到图片
    CGImageRef scaledImage = CGBitmapContextCreateImage(bitmapRef);
    CGContextRelease(bitmapRef);
    CGImageRelease(bitmapImage);
  
    self.imageV1.image = [UIImage imageWithCGImage:scaledImage];
    [MyProgressHUD dismiss];
    
}

//点击图片事件
-(void)doTap
{
    [self.textV1 resignFirstResponder];
    [ZZQAvatarPicker startSelected:^(UIImage * _Nonnull image) {
        self.imageV1.image = image;
    }];
}

-(void)saveBtnAction
{
    if (self.imageV1.image == nil)
    {
        
        if ([[[ViewManager shareInstance] getPreferredLanguage] isEqualToString:@"zh-Hans-CN"])
        {
           [MyProgressHUD showErrorWithStatus:@"没有图片可以保存"];
        }
        else
        {
            [MyProgressHUD showErrorWithStatus:@"There are no pictures to save"];
        }
        
        return;
    }
    UIImageWriteToSavedPhotosAlbum(self.imageV1.image, self, @selector(image:didFinishSavingWithError:contextInfo:), nil);
}
-(void)shareBtnAction
{
    if (self.imageV1.image == nil)
    {
        if ([[[ViewManager shareInstance] getPreferredLanguage] isEqualToString:@"zh-Hans-CN"])
        {
            [MyProgressHUD showErrorWithStatus:@"没有图片可以分享"];
        }
        else
        {
            [MyProgressHUD showErrorWithStatus:@"No pictures to share"];
        }
        return;
    }
    NSArray *activityItems = @[self.imageV1.image];
    UIActivityViewController *activityVC = [[UIActivityViewController alloc]initWithActivityItems:activityItems applicationActivities:nil];
    
    [self presentViewController:activityVC animated:YES completion:nil];
}


//回车键退出键盘
-(BOOL)textView:(UITextView *)textView shouldChangeTextInRange:(NSRange)range replacementText:(NSString *)text
{
    if ([text isEqualToString:@"\n"])
    {
        [textView resignFirstResponder];
        return NO;
    }
    return YES;
}
//图片保存到相册后的回调
- (void)image:(UIImage *)image didFinishSavingWithError:(NSError *)error contextInfo:(void *)contextInfo
{
    if (error == nil)
    {
        [MyProgressHUD showSuccessWithStatus:@"保存成功"];
    }
    NSLog(@"image = %@, error = %@, contextInfo = %@", image, error, contextInfo);
}
/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
