//
//  FirstViewController.h
//  ApeTools
//
//  Created by 王亚坤 on 2019/3/2.
//  Copyright © 2019 王亚坤. All rights reserved.
//

#import "BaseViewController.h"
#import "Base64ViewController.h"
#import "UrlViewController.h"
#import "BinaryViewController.h"
#import "QRCodeViewController.h"
#import "ColorValueViewController.h"
NS_ASSUME_NONNULL_BEGIN

@interface FirstViewController : BaseViewController<UITableViewDelegate,UITableViewDataSource>
@property (nonatomic,strong) UITableView * tab;
@end

NS_ASSUME_NONNULL_END
