//
//  ColorValueViewController.h
//  ApeTools
//
//  Created by 王亚坤 on 2019/3/2.
//  Copyright © 2019 王亚坤. All rights reserved.
//

#import "BaseViewController.h"
#import "PickerView.h"

NS_ASSUME_NONNULL_BEGIN

@interface ColorValueViewController : BaseViewController<UITableViewDelegate,UITableViewDataSource,UITextViewDelegate,PickerViewResultDelegate>
@property (nonatomic,strong) UITextView * textV1;
@property (nonatomic,strong) UITextView * textV2;
@property (nonatomic,strong) UITextView * textV3;
@property (nonatomic,strong) UITextView * textV4;
@property (nonatomic,strong) UITextView * textV5;
@property (nonatomic,strong) UITextView * textV6;
@property (nonatomic,strong) UILabel * InputLab1;
@property (nonatomic,strong) UILabel * InputLab2;
@property (nonatomic,strong) UILabel * InputLab3;
@property (nonatomic,strong) UILabel * InputLab4;
@property (nonatomic,strong) UITextView * IputTextV1;
@property (nonatomic,strong) UITextView * IputTextV2;
@property (nonatomic,strong) UITextView * IputTextV3;
@property (nonatomic,strong) UITextView * IputTextV4;



@property (nonatomic,strong) UITableView * tab;
@property (nonatomic,strong) UIButton * btnL;
@property (nonatomic,strong) PickerView * pickerV;
@end

NS_ASSUME_NONNULL_END
