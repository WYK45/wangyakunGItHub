//
//  QRCodeViewController.h
//  ApeTools
//
//  Created by 王亚坤 on 2019/3/2.
//  Copyright © 2019 王亚坤. All rights reserved.
//

#import "BaseViewController.h"
#import <AssetsLibrary/AssetsLibrary.h>
#import "ZZQAvatarPicker.h"
#import "MyProgressHUD.h"
#import <Social/Social.h>

NS_ASSUME_NONNULL_BEGIN

@interface QRCodeViewController : BaseViewController<UITableViewDelegate,UITableViewDataSource,UITextViewDelegate,UIImagePickerControllerDelegate>
@property (nonatomic,strong) UIImageView * imageV1;
@property (nonatomic,strong) UITextView * textV1;
@property (nonatomic,strong) UITextView * textV2;
@property (nonatomic,strong) UITableView * tab;
@end

NS_ASSUME_NONNULL_END
