//
//  ColorValueViewController.m
//  ApeTools
//
//  Created by 王亚坤 on 2019/3/2.
//  Copyright © 2019 王亚坤. All rights reserved.
//

#import "ColorValueViewController.h"

@interface ColorValueViewController ()

@end

@implementation ColorValueViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
     [self setTopTitle:@"ColorValue"];
    [self setBackBtnHide:NO];
    [self.view addSubview:self.tab];
}
-(UITextView *)textV1
{
    if (!_textV1)
    {
        _textV1 = [[UITextView alloc]initWithFrame:CGRectMake(FitX(20), FitY(120), FitWidth(710), FitHeight(75))];
        _textV1.layer.borderWidth = 1.0f;
        _textV1.layer.borderColor = [UIColor blackColor].CGColor;
        _textV1.delegate = self;
    }
    return _textV1;
}

-(UITextView *)textV2
{
    if (!_textV2)
    {
        _textV2 = [[UITextView alloc]initWithFrame:CGRectMake(FitX(200), FitY(120)+self.textV1.frame.size.height+FitHeight(150), FitWidth(710-180), FitHeight(75))];
        //        _textV2.layer.borderWidth = 1.0f;
        //        _textV2.layer.borderColor = [UIColor blackColor].CGColor;
        _textV2.delegate = self;
    }
    return _textV2;
}
-(UILabel *)InputLab1
{
    if (!_InputLab1)
    {
        _InputLab1 = [self createLabel:CGRectMake(FitX(20), FitY(110), FitWidth(80), FitHeight(40)) title:@"R:" fontSize:FitFont(30) textColor:MainColor];
    }
    return _InputLab1;
}
-(UITextView *)IputTextV1
{
    if (!_IputTextV1)
    {
        _IputTextV1 = [[UITextView alloc]initWithFrame:CGRectMake(FitX(80), FitY(100), FitWidth(80), FitHeight(60))];
        
        _IputTextV1.textAlignment = NSTextAlignmentCenter;
        _IputTextV1.layer.borderWidth = 1.0f;
        _IputTextV1.layer.borderColor = [UIColor blackColor].CGColor;
        _IputTextV1.delegate = self;
    }
    return _IputTextV1;
}

-(UILabel *)InputLab2
{
    if (!_InputLab2)
    {
        _InputLab2 = [self createLabel:CGRectMake(FitX(210), FitY(110), FitWidth(80), FitHeight(40)) title:@"G:" fontSize:FitFont(30) textColor:MainColor];
    }
    return _InputLab2;
}
-(UITextView *)IputTextV2
{
    if (!_IputTextV2)
    {
        _IputTextV2 = [[UITextView alloc]initWithFrame:CGRectMake(FitX(270), FitY(100), FitWidth(80), FitHeight(60))];
        
        _IputTextV2.textAlignment = NSTextAlignmentCenter;
        _IputTextV2.layer.borderWidth = 1.0f;
        _IputTextV2.layer.borderColor = [UIColor blackColor].CGColor;
        _IputTextV2.delegate = self;
    }
    return _IputTextV2;
}

-(UILabel *)InputLab3
{
    if (!_InputLab3)
    {
        _InputLab3 = [self createLabel:CGRectMake(FitX(170+150+80), FitY(110), FitWidth(80), FitHeight(40)) title:@"B:" fontSize:FitFont(30) textColor:MainColor];
    }
    return _InputLab3;
}
-(UITextView *)IputTextV3
{
    if (!_IputTextV3)
    {
        _IputTextV3 = [[UITextView alloc]initWithFrame:CGRectMake(FitX(210+150+100), FitY(100), FitWidth(80), FitHeight(60))];
       
        _IputTextV3.textAlignment = NSTextAlignmentCenter;
        _IputTextV3.layer.borderWidth = 1.0f;
        _IputTextV3.layer.borderColor = [UIColor blackColor].CGColor;
        _IputTextV3.delegate = self;
    }
    return _IputTextV3;
}

-(UILabel *)InputLab4
{
    if (!_InputLab4)
    {
        _InputLab4 = [self createLabel:CGRectMake(FitX(170+300+120), FitY(110), FitWidth(80), FitHeight(40)) title:@"Y:" fontSize:FitFont(30) textColor:MainColor];
    }
    return _InputLab4;
}
-(UITextView *)IputTextV4
{
    if (!_IputTextV4)
    {
        _IputTextV4 = [[UITextView alloc]initWithFrame:CGRectMake(FitX(210+300+140), FitY(100), FitWidth(80), FitHeight(60))];
        _IputTextV4.textAlignment = NSTextAlignmentCenter;
        _IputTextV4.layer.borderWidth = 1.0f;
        _IputTextV4.layer.borderColor = [UIColor blackColor].CGColor;
        _IputTextV4.delegate = self;
    }
    return _IputTextV4;
}



-(UITableView *)tab{
    if (!_tab)
    {
        _tab = [[UITableView alloc]initWithFrame:CGRectMake(0,TopAndSystemHeight, ScreenWidth, ScreenHeight-TopAndSystemHeight)];
        _tab.delegate = self;
        _tab.dataSource = self;
    }
    return _tab;
}
-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return 1;
}
-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    UITableViewCell * cell = [tableView dequeueReusableCellWithIdentifier:@"cellid"];
    if (!cell)
    {
        cell = [[UITableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"cellid"];
//        [cell addSubview:self.textV1];
        [cell addSubview:self.textV2];
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
        
        [cell addSubview:self.InputLab1];
        [cell addSubview:self.IputTextV1];
        [cell addSubview:self.InputLab2];
        [cell addSubview:self.IputTextV2];
        [cell addSubview:self.InputLab3];
        [cell addSubview:self.IputTextV3];
        self.IputTextV4.hidden = YES;
        self.InputLab4.hidden = YES;
        [cell addSubview:self.InputLab4];
        [cell addSubview:self.IputTextV4];
        
        
        
        
        
        UILabel * lab1 = [self createLabel:CGRectMake(FitX(20), FitY(30), FitWidth(300), FitHeight(40)) title:@"所选输入数据类型：" fontSize:FitFont(30) textColor:MainColor];
        
        
        if ([[[ViewManager shareInstance] getPreferredLanguage] isEqualToString:@"zh-Hans-CN"])
        {
            lab1.text = @"所选输入数据类型：";
        }
        else
        {
            lab1.text = @"input data type：";
        }
        
        
        [cell addSubview:lab1];
        
        UILabel * lab2 = [self createLabel:CGRectMake(FitX(20), FitY(130)+self.textV1.frame.size.height+FitHeight(150), FitWidth(200), FitHeight(40)) title:@"RGB:" fontSize:FitFont(30) textColor:MainColor];
        lab2.textAlignment = NSTextAlignmentCenter;
        [cell addSubview:lab2];
        
        UILabel * lab3 = [self createLabel:CGRectMake(FitX(20), FitY(230)+self.textV1.frame.size.height+FitHeight(150), FitWidth(200), FitHeight(40)) title:@"CMYK:" fontSize:FitFont(30) textColor:MainColor];
        lab3.textAlignment = NSTextAlignmentCenter;
        [cell addSubview:lab3];
        
        _textV3 = [[UITextView alloc]initWithFrame:CGRectMake(FitX(200), FitY(220)+self.textV1.frame.size.height+FitHeight(150), FitWidth(710-180), FitHeight(75))];
        _textV3.delegate = self;
        [cell addSubview:_textV3];
        
        
        UILabel * lab4 = [self createLabel:CGRectMake(FitX(20), FitY(330)+self.textV1.frame.size.height+FitHeight(150), FitWidth(200), FitHeight(40)) title:@"HSV:" fontSize:FitFont(30) textColor:MainColor];
        lab4.textAlignment = NSTextAlignmentCenter;
        [cell addSubview:lab4];
        
        _textV4 = [[UITextView alloc]initWithFrame:CGRectMake(FitX(200), FitY(320)+self.textV1.frame.size.height+FitHeight(150), FitWidth(710-180), FitHeight(75))];
        _textV4.delegate = self;
        [cell addSubview:_textV4];
        
        
        UILabel * lab5 = [self createLabel:CGRectMake(FitX(20), FitY(430)+self.textV1.frame.size.height+FitHeight(150), FitWidth(200), FitHeight(40)) title:@"YIQ:" fontSize:FitFont(30) textColor:MainColor];
        lab5.textAlignment = NSTextAlignmentCenter;
        [cell addSubview:lab5];
        
        _textV5 = [[UITextView alloc]initWithFrame:CGRectMake(FitX(200), FitY(420)+self.textV1.frame.size.height+FitHeight(150), FitWidth(710-180), FitHeight(75))];
        _textV5.delegate = self;
        [cell addSubview:_textV5];
        
        
        UILabel * lab6 = [self createLabel:CGRectMake(FitX(20), FitY(530)+self.textV1.frame.size.height+FitHeight(150), FitWidth(200), FitHeight(40)) title:@"YCbCr:" fontSize:FitFont(30) textColor:MainColor];
        lab6.textAlignment = NSTextAlignmentCenter;
        [cell addSubview:lab6];
        
        _textV6 = [[UITextView alloc]initWithFrame:CGRectMake(FitX(200), FitY(520)+self.textV1.frame.size.height+FitHeight(150), FitWidth(710-180), FitHeight(75))];
        _textV6.delegate = self;
        [cell addSubview:_textV6];
        
        
        
        _btnL = [self createBtn:CGRectMake(FitX(300), FitY(25), FitWidth(180), FitHeight(50)) title:@"RGB" iconImage:nil backgroundImage:nil tag:6000 textColor:[UIColor whiteColor]];
        [_btnL setBackgroundColor:MainColor];
        _btnL.layer.cornerRadius = 5.0f;
        [_btnL addTarget:self action:@selector(btnLAction) forControlEvents:UIControlEventTouchUpInside];
        [cell addSubview:_btnL];
        
        //        UIImageView * imagUP = [[UIImageView alloc]initWithFrame:CGRectMake(FitX(355), FitY(238), FitWidth(17), FitHeight(65))];
        //        imagUP.image = [UIImage imageNamed:@"箭头上"];
        //        [cell addSubview:imagUP];
        
        //        UIImageView * imagDOWN = [[UIImageView alloc]initWithFrame:CGRectMake(FitX(378), FitY(238), FitWidth(17), FitHeight(65))];
        //        imagDOWN.image = [UIImage imageNamed:@"箭头下"];
        //        [cell addSubview:imagDOWN];
        
        UIButton * btnR = [self createBtn:CGRectMake(FitX(400), FitY(245), FitWidth(180), FitHeight(50)) title:@"开始转换" iconImage:nil backgroundImage:nil tag:6000 textColor:[UIColor whiteColor]];
        
        if ([[[ViewManager shareInstance] getPreferredLanguage] isEqualToString:@"zh-Hans-CN"])
        {
            [btnR setTitle:@"开始转换" forState:UIControlStateNormal];
        }
        else
        {
            [btnR setTitle:@"To transform" forState:UIControlStateNormal];
        }
        
        
        [btnR setBackgroundColor:MainColor];
        btnR.layer.cornerRadius = 5.0f;
        [btnR addTarget:self action:@selector(btnRAction) forControlEvents:UIControlEventTouchUpInside];
        [cell addSubview:btnR];
        
        //        UIButton * ShareBtn = [self createBtn:CGRectMake(FitX(205), FitY(460), FitWidth(340), FitHeight(65)) title:@"分享并拷贝到粘贴板" iconImage:nil backgroundImage:nil tag:60050 textColor:[UIColor whiteColor]];
        //        [ShareBtn setBackgroundColor:MainColor];
        //        ShareBtn.titleLabel.textAlignment = NSTextAlignmentCenter;
        //        ShareBtn.layer.cornerRadius = 5.0f;
        //        [ShareBtn addTarget:self action:@selector(ShareAction) forControlEvents:UIControlEventTouchUpInside];
        //        [cell addSubview:ShareBtn];
        
        
        
        
    }
    return cell;
}
-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return (FitHeight(750)*2);
}

-(void)btnLAction
{
    _pickerV = [[PickerView alloc]init];
    _pickerV.type = PickerViewTypeWeight;
    _pickerV.delegate = self;
    [self.view addSubview:_pickerV];
}
-(void)btnRAction
{
    
    if ([self.btnL.titleLabel.text isEqualToString:@"RGB"])
    {
        self.textV2.text = [NSString stringWithFormat:@"R:%d  G:%d  B:%d",[_IputTextV1.text intValue],[_IputTextV2.text intValue],[_IputTextV3.text intValue]];
       NSMutableArray * arr = [self RGB_2_HSV_withR:[_IputTextV1.text intValue] G:[_IputTextV2.text intValue] B:[_IputTextV3.text intValue]];
        NSMutableString * muStr = [[NSMutableString alloc]init];
        [muStr appendString:[NSString stringWithFormat:@"H:%@     ",arr[0]]];
        [muStr appendString:[NSString stringWithFormat:@"S:%@     ",arr[1]]];
        [muStr appendString:[NSString stringWithFormat:@"V:%@     ",arr[2]]];
        _textV4.text = [muStr copy];
        
        
        int y = [_IputTextV1.text intValue];
        int i = [_IputTextV2.text intValue];
        int q = [_IputTextV3.text intValue];
        int k = [_IputTextV4.text intValue];
        self.textV5.text = [NSString stringWithFormat:@"R:%d  G:%d  B:%d",y+20,i+25,q+14];
        self.textV3.text = [NSString stringWithFormat:@"C:%d  M:%d  Y:%d  K:%d",y,i,q,k];
        self.textV6.text = [NSString stringWithFormat:@"Y:%d  I:%d  Q:%d",y-15,i/6,q+3];
        
    }
    else if ([self.btnL.titleLabel.text isEqualToString:@"CMYK"])
    {
        int y = [_IputTextV1.text intValue];
        int i = [_IputTextV2.text intValue];
        int q = [_IputTextV3.text intValue];
        int k = [_IputTextV4.text intValue];
        self.textV5.text = [NSString stringWithFormat:@"R:%d  G:%d  B:%d",y+20,i+25,q+14];
        self.textV3.text = [NSString stringWithFormat:@"C:%d  M:%d  Y:%d  K:%d",y,i,q,k];
        self.textV2.text = [NSString stringWithFormat:@"H:%d  S:%d  V:%d",y/6,i+80,q-1];
        self.textV6.text = [NSString stringWithFormat:@"Y:%d  I:%d  Q:%d",y-15,i/6,q+3];
        self.textV4.text = [NSString stringWithFormat:@"Y:%d  Cb:%d  Cr:%d",(y+i)/2,(i+q)/3,q++];
    }
    else if ([self.btnL.titleLabel.text isEqualToString:@"HSV"])
    {
        self.textV4.text = [NSString stringWithFormat:@"H:%d  S:%d  V:%d",[_IputTextV1.text intValue],[_IputTextV2.text intValue],[_IputTextV3.text intValue]];
        
        NSMutableArray * arr = [self HSV_2_RGB_withH:[_IputTextV1.text intValue] S:[_IputTextV2.text intValue] V:[_IputTextV3.text intValue]];
        NSMutableString * muStr = [[NSMutableString alloc]init];
        [muStr appendString:[NSString stringWithFormat:@"R:%@     ",arr[0]]];
        [muStr appendString:[NSString stringWithFormat:@"G:%@     ",arr[1]]];
        [muStr appendString:[NSString stringWithFormat:@"B:%@     ",arr[2]]];
        _textV2.text = [muStr copy];
        
        
        
        int y = [_IputTextV1.text intValue];
        int i = [_IputTextV2.text intValue];
        int q = [_IputTextV3.text intValue];
        int k = [_IputTextV4.text intValue];
        self.textV5.text = [NSString stringWithFormat:@"R:%d  G:%d  B:%d",y+30,i/25,q+1];
        self.textV3.text = [NSString stringWithFormat:@"C:%d  M:%d  Y:%d  K:%d",y*2,i-0,q+10,k/2];
        self.textV6.text = [NSString stringWithFormat:@"Y:%d  I:%d  Q:%d",y+15,i-6,q+9];
    }
    else if ([self.btnL.titleLabel.text isEqualToString:@"YIQ"])
    {
        int y = [_IputTextV1.text intValue];
        int i = [_IputTextV2.text intValue];
        int q = [_IputTextV3.text intValue];
        self.textV2.text = [NSString stringWithFormat:@"R:%d  G:%d  B:%d",y+20,i+25,q+14];
        self.textV3.text = [NSString stringWithFormat:@"C:%d  M:%d  Y:%d  K:%d",y++,i/2,q+10,q++];
        self.textV4.text = [NSString stringWithFormat:@"H:%d  S:%d  V:%d",y/6,i+80,q-1];
        self.textV5.text = [NSString stringWithFormat:@"Y:%d  I:%d  Q:%d",y,i,q];
        self.textV6.text = [NSString stringWithFormat:@"Y:%d  Cb:%d  Cr:%d",(y+i)/2,(i+q)/3,q++];
        
    }
    else        //YCbCr
    {
        int y = [_IputTextV1.text intValue];
        int i = [_IputTextV2.text intValue];
        int q = [_IputTextV3.text intValue];
        self.textV5.text = [NSString stringWithFormat:@"R:%d  G:%d  B:%d",y+20,i+25,q+14];
        self.textV3.text = [NSString stringWithFormat:@"C:%d  M:%d  Y:%d  K:%d",y+6,i/2,q+20,q++/2];
        self.textV2.text = [NSString stringWithFormat:@"H:%d  S:%d  V:%d",y/6,i+80,q-1];
        self.textV6.text = [NSString stringWithFormat:@"Y:%d  I:%d  Q:%d",y,i,q];
        self.textV4.text = [NSString stringWithFormat:@"Y:%d  Cb:%d  Cr:%d",(y+i)/2,(i+q)/3,q++];
    }
}

-(void)ShareAction
{
    
}

//选择结果
- (void)pickerView:(UIView *)pickerView result:(NSString *)string
{
    NSLog(@"string = %@",string);
     [_btnL setTitle:string forState:UIControlStateNormal];
    if ([string isEqualToString:@"RGB"])
    {
        self.InputLab4.hidden = YES;
        self.IputTextV4.hidden = YES;
        _InputLab1.text = @"R:";
        _InputLab2.text = @"G:";
        _InputLab3.text = @"B:";
    }
    else if ([string isEqualToString:@"CMYK"])
    {
        self.InputLab4.hidden = NO;
        self.IputTextV4.hidden = NO;
        _InputLab1.text = @"C:";
        _InputLab2.text = @"M:";
        _InputLab3.text = @"Y:";
        _InputLab4.text = @"K:";
    }
    else if ([string isEqualToString:@"HSV"])
    {
        self.InputLab4.hidden = YES;
        self.IputTextV4.hidden = YES;
        _InputLab1.text = @"H:";
        _InputLab2.text = @"S:";
        _InputLab3.text = @"V:";
    }
    else if ([string isEqualToString:@"YIQ"])
    {
        self.InputLab4.hidden = YES;
        self.IputTextV4.hidden = YES;
        _InputLab1.text = @"Y:";
        _InputLab2.text = @"I:";
        _InputLab3.text = @"Q:";
    }
    else        //YCbCr
    {
        self.InputLab4.hidden = YES;
        self.IputTextV4.hidden = YES;
        _InputLab1.text = @"Y:";
        _InputLab2.text = @"Cb:";
        _InputLab3.text = @"Cr:";
    }
   
}
//RGB2HSV
-(NSMutableArray *)RGB_2_HSV_withR:(int)r G:(int)g B:(int)b
{
    int wykMax = [self max_maxR:r G:g B:b];
    int wykMin = [self min_minR:r G:g B:b];
    
    int V = wykMax;
    int S = (wykMax - wykMin)/wykMax;
    int H = 0;
    if (r == wykMax) H =(g-b)/(wykMax-wykMin)* 60;
    if (g == wykMax) H = 120+(b-r)/(wykMax-wykMin)* 60;
    if (b == wykMax) H = 240 +(r-g)/(wykMax-wykMin)* 60;
    if (H < 0) H = H+ 360;
    
    NSMutableArray * arr = [[NSMutableArray alloc]init];
    [arr addObject:[NSString stringWithFormat:@"%d",H]];
    [arr addObject:[NSString stringWithFormat:@"%d",S]];
    [arr addObject:[NSString stringWithFormat:@"%d",V]];
    return arr;
}
//HSV2RGB
-(NSMutableArray *)HSV_2_RGB_withH:(int)h S:(int)s V:(int)v
{
    int R=0,G=0,B=0;
    if (s==0)
    {
        R=G=B=0;
    }
    else
    {
        
        int i= (int)(h/=60);
        float f = h-i;
        float a = v*(1-s);
        float b = v*(1-s*f);
        float c = v*(1-s*(1-f));
        switch (i)
        {
            case 0:
                R = v;
                G = c;
                B = a;
                break;
            case 1:
                R = b;
                G = v;
                B = a;
                break;
            case 2:
                R = a;
                G = v;
                B = c;
                break;
            case 3:
                R = a;
                G = b;
                B = v;
                break;
            case 4:
                R = c;
                G = a;
                B = v;
                break;
            case 5:
                R = v;
                G = a;
                B = b;
                break;
                
            default:
                break;
        }
    }
    
    NSMutableArray * arr = [[NSMutableArray alloc]init];
    [arr addObject:[NSString stringWithFormat:@"%d",R]];
    [arr addObject:[NSString stringWithFormat:@"%d",G]];
    [arr addObject:[NSString stringWithFormat:@"%d",B]];
    return arr;
}

//RGB2CMYK


-(int)max_maxR:(int)r G:(int)g B:(int)b
{
    int max = 0;
    if (r>=g)
    {
        max = r;
    }
    else
    {
        max = g;
    }
    if (max>=b) {
        return max;
    }
    else
    {
        return b;
    }
}
-(int)min_minR:(int)r G:(int)g B:(int)b
{
    int min = 0;
    if (r<=g)
    {
        min = r;
    }
    else
    {
        min = g;
    }
    if (min<=b) {
        return min;
    }
    else
    {
        return b;
    }
}
//回车键退出键盘
-(BOOL)textView:(UITextView *)textView shouldChangeTextInRange:(NSRange)range replacementText:(NSString *)text
{
    if ([text isEqualToString:@"\n"])
    {
        [textView resignFirstResponder];
        return NO;
    }
    return YES;
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
