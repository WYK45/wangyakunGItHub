//
//  UrlViewController.h
//  ApeTools
//
//  Created by 王亚坤 on 2019/3/2.
//  Copyright © 2019 王亚坤. All rights reserved.
//

#import "BaseViewController.h"
#import "MyProgressHUD.h"

NS_ASSUME_NONNULL_BEGIN

@interface UrlViewController : BaseViewController<UITableViewDelegate,UITableViewDataSource,UITextViewDelegate>
@property (nonatomic,strong) UITextView * textV1;
@property (nonatomic,strong) UITextView * textV2;
@property (nonatomic,strong) UITableView * tab;
@end

NS_ASSUME_NONNULL_END
