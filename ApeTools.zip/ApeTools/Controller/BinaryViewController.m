//
//  BinaryViewController.m
//  ApeTools
//
//  Created by 王亚坤 on 2019/3/2.
//  Copyright © 2019 王亚坤. All rights reserved.
//

#import "BinaryViewController.h"

@interface BinaryViewController ()

@end

@implementation BinaryViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    if ([[[ViewManager shareInstance] getPreferredLanguage] isEqualToString:@"zh-Hans-CN"])
    {
        [self setTopTitle:@"进制转换"];
    }
    else
    {
        [self setTopTitle:@"Binary sys"];
    }
    
    
    [self setBackBtnHide:NO];
    [self.view addSubview:self.tab];
}
-(UITextView *)textV1
{
    if (!_textV1)
    {
        _textV1 = [[UITextView alloc]initWithFrame:CGRectMake(FitX(20), FitY(120), FitWidth(710), FitHeight(75))];
        _textV1.layer.borderWidth = 1.0f;
        _textV1.layer.borderColor = [UIColor blackColor].CGColor;
        _textV1.delegate = self;
    }
    return _textV1;
}

-(UITextView *)textV2
{
    if (!_textV2)
    {
        _textV2 = [[UITextView alloc]initWithFrame:CGRectMake(FitX(200), FitY(120)+self.textV1.frame.size.height+FitHeight(150), FitWidth(710-180), FitHeight(75))];
//        _textV2.layer.borderWidth = 1.0f;
//        _textV2.layer.borderColor = [UIColor blackColor].CGColor;
    }
    return _textV2;
}

-(UITableView *)tab{
    if (!_tab)
    {
        _tab = [[UITableView alloc]initWithFrame:CGRectMake(0,TopAndSystemHeight, ScreenWidth, ScreenHeight-TopAndSystemHeight)];
        _tab.delegate = self;
        _tab.dataSource = self;
    }
    return _tab;
}
-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return 1;
}
-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    UITableViewCell * cell = [tableView dequeueReusableCellWithIdentifier:@"cellid"];
    if (!cell)
    {
        cell = [[UITableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"cellid"];
        [cell addSubview:self.textV1];
        [cell addSubview:self.textV2];
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
        
        
        
        
        
        UILabel * lab1 = [self createLabel:CGRectMake(FitX(20), FitY(30), FitWidth(300), FitHeight(40)) title:@"所选输入数据类型：" fontSize:FitFont(30) textColor:MainColor];
        
        
        if ([[[ViewManager shareInstance] getPreferredLanguage] isEqualToString:@"zh-Hans-CN"])
        {
            lab1.text = @"所选输入数据类型：";
        }
        else
        {
             lab1.text = @"input data type：";
        }
        
        
        [cell addSubview:lab1];
        
        UILabel * lab2 = [self createLabel:CGRectMake(FitX(20), FitY(130)+self.textV1.frame.size.height+FitHeight(150), FitWidth(200), FitHeight(40)) title:@"二进制：" fontSize:FitFont(30) textColor:MainColor];
        lab2.textAlignment = NSTextAlignmentCenter;
        [cell addSubview:lab2];
        
        UILabel * lab3 = [self createLabel:CGRectMake(FitX(20), FitY(230)+self.textV1.frame.size.height+FitHeight(150), FitWidth(200), FitHeight(40)) title:@"十进制：" fontSize:FitFont(30) textColor:MainColor];
        lab3.textAlignment = NSTextAlignmentCenter;
        [cell addSubview:lab3];
        
        _textV3 = [[UITextView alloc]initWithFrame:CGRectMake(FitX(200), FitY(220)+self.textV1.frame.size.height+FitHeight(150), FitWidth(710-180), FitHeight(75))];
        [cell addSubview:_textV3];
        
        
        UILabel * lab4 = [self createLabel:CGRectMake(FitX(20), FitY(330)+self.textV1.frame.size.height+FitHeight(150), FitWidth(200), FitHeight(40)) title:@"十六进制：" fontSize:FitFont(30) textColor:MainColor];
        lab4.textAlignment = NSTextAlignmentCenter;
        [cell addSubview:lab4];
        
        _textV4 = [[UITextView alloc]initWithFrame:CGRectMake(FitX(200), FitY(320)+self.textV1.frame.size.height+FitHeight(150), FitWidth(710-180), FitHeight(75))];
        [cell addSubview:_textV4];
        
        
        
        
        if ([[[ViewManager shareInstance] getPreferredLanguage] isEqualToString:@"zh-Hans-CN"])
        {
            _btnL = [self createBtn:CGRectMake(FitX(300), FitY(25), FitWidth(180), FitHeight(50)) title:@"十进制" iconImage:nil backgroundImage:nil tag:6000 textColor:[UIColor whiteColor]];
        }
        else
        {
            _btnL = [self createBtn:CGRectMake(FitX(300), FitY(25), FitWidth(180), FitHeight(50)) title:@"Decimal" iconImage:nil backgroundImage:nil tag:6000 textColor:[UIColor whiteColor]];
        }
        
        
        [_btnL setBackgroundColor:MainColor];
        _btnL.layer.cornerRadius = 5.0f;
        [_btnL addTarget:self action:@selector(btnLAction) forControlEvents:UIControlEventTouchUpInside];
        [cell addSubview:_btnL];
        
        
        
        if ([[[ViewManager shareInstance] getPreferredLanguage] isEqualToString:@"zh-Hans-CN"])
        {
            
        }
        else
        {
            lab2.text = @"Binary";
            lab3.text = @"Decimal";
            lab4.text = @"Hexadecimal";
        }
        
        
        
        
        
//        UIImageView * imagUP = [[UIImageView alloc]initWithFrame:CGRectMake(FitX(355), FitY(238), FitWidth(17), FitHeight(65))];
//        imagUP.image = [UIImage imageNamed:@"箭头上"];
//        [cell addSubview:imagUP];
        
//        UIImageView * imagDOWN = [[UIImageView alloc]initWithFrame:CGRectMake(FitX(378), FitY(238), FitWidth(17), FitHeight(65))];
//        imagDOWN.image = [UIImage imageNamed:@"箭头下"];
//        [cell addSubview:imagDOWN];
        
        UIButton * btnR = [self createBtn:CGRectMake(FitX(400), FitY(245), FitWidth(180), FitHeight(50)) title:@"开始转换" iconImage:nil backgroundImage:nil tag:6000 textColor:[UIColor whiteColor]];
        
        
        if ([[[ViewManager shareInstance] getPreferredLanguage] isEqualToString:@"zh-Hans-CN"])
        {
            [btnR setTitle:@"开始转换" forState:UIControlStateNormal];
        }
        else
        {
           [btnR setTitle:@"To transform" forState:UIControlStateNormal];
        }
        
        
        [btnR setBackgroundColor:MainColor];
        btnR.layer.cornerRadius = 5.0f;
        [btnR addTarget:self action:@selector(btnRAction) forControlEvents:UIControlEventTouchUpInside];
        [cell addSubview:btnR];
        
//        UIButton * ShareBtn = [self createBtn:CGRectMake(FitX(205), FitY(460), FitWidth(340), FitHeight(65)) title:@"分享并拷贝到粘贴板" iconImage:nil backgroundImage:nil tag:60050 textColor:[UIColor whiteColor]];
//        [ShareBtn setBackgroundColor:MainColor];
//        ShareBtn.titleLabel.textAlignment = NSTextAlignmentCenter;
//        ShareBtn.layer.cornerRadius = 5.0f;
//        [ShareBtn addTarget:self action:@selector(ShareAction) forControlEvents:UIControlEventTouchUpInside];
//        [cell addSubview:ShareBtn];
        
        
        
        
    }
    return cell;
}
-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return (FitHeight(700)*2);
}
-(void)btnLAction
{
    _pickerV = [[PickerView alloc]init];
    _pickerV.type = PickerViewTypeHeigh;
    _pickerV.delegate = self;
    [self.view addSubview:_pickerV];
}
-(void)btnRAction
{
    if ([_btnL.titleLabel.text isEqualToString:@"十进制"]||[_btnL.titleLabel.text isEqualToString:@"Decimal"])
    {
        self.textV2.text = [self getBinaryByDecimal:[self.textV1.text longLongValue]];//十转二
        self.textV3.text = self.textV1.text;
        self.textV4.text = [self getHexByDecimal:[self.textV1.text longLongValue]];//十转十六
    }
    else if ([_btnL.titleLabel.text isEqualToString:@"十六进制"]||[_btnL.titleLabel.text isEqualToString:@"Hexadecimal"])
    
    {
        self.textV2.text = [self getBinaryByHex:self.textV1.text];
         self.textV3.text = [NSString stringWithFormat:@"%ld",(long)[self getDecimalByBinary:self.textV2.text]];//二转十
        self.textV4.text = self.textV1.text;
    }
    else
    {
        self.textV4.text = [self getHexByBinary:self.textV1.text];//二转十六
        self.textV3.text = [NSString stringWithFormat:@"%ld",(long)[self getDecimalByBinary:self.textV1.text]];//二转十
        self.textV2.text = self.textV1.text;
        
        
    }
    
}

-(void)ShareAction
{
    
}
//十进制转换为二进制
- (NSString *)getBinaryByDecimal:(NSInteger)decimal {
    
    NSString *binary = @"";
    while (decimal) {
        
        binary = [[NSString stringWithFormat:@"%ld", decimal % 2] stringByAppendingString:binary];
        if (decimal / 2 < 1) {
            
            break;
        }
        decimal = decimal / 2 ;
    }
    if (binary.length % 4 != 0) {
        
        NSMutableString *mStr = [[NSMutableString alloc]init];;
        for (int i = 0; i < 4 - binary.length % 4; i++) {
            
            [mStr appendString:@"0"];
        }
        binary = [mStr stringByAppendingString:binary];
    }
    return binary;
}
//十进制转换为十六进制
-(NSString *)getHexByDecimal:(NSInteger)decimal {
    
    NSString *hex =@"";
    NSString *letter;
    NSInteger number;
    for (int i = 0; i<9; i++) {
        
        number = decimal % 16;
        decimal = decimal / 16;
        switch (number) {
                
            case 10:
                letter =@"A"; break;
            case 11:
                letter =@"B"; break;
            case 12:
                letter =@"C"; break;
            case 13:
                letter =@"D"; break;
            case 14:
                letter =@"E"; break;
            case 15:
                letter =@"F"; break;
            default:
                letter = [NSString stringWithFormat:@"%ld", number];
        }
        hex = [letter stringByAppendingString:hex];
        if (decimal == 0) {
            
            break;
        }
    }
    return hex;
}
//二进制转十六进制
- (NSString *)getHexByBinary:(NSString *)binary {
    
    NSMutableDictionary *binaryDic = [[NSMutableDictionary alloc] initWithCapacity:16];
    [binaryDic setObject:@"0" forKey:@"0000"];
    [binaryDic setObject:@"1" forKey:@"0001"];
    [binaryDic setObject:@"2" forKey:@"0010"];
    [binaryDic setObject:@"3" forKey:@"0011"];
    [binaryDic setObject:@"4" forKey:@"0100"];
    [binaryDic setObject:@"5" forKey:@"0101"];
    [binaryDic setObject:@"6" forKey:@"0110"];
    [binaryDic setObject:@"7" forKey:@"0111"];
    [binaryDic setObject:@"8" forKey:@"1000"];
    [binaryDic setObject:@"9" forKey:@"1001"];
    [binaryDic setObject:@"A" forKey:@"1010"];
    [binaryDic setObject:@"B" forKey:@"1011"];
    [binaryDic setObject:@"C" forKey:@"1100"];
    [binaryDic setObject:@"D" forKey:@"1101"];
    [binaryDic setObject:@"E" forKey:@"1110"];
    [binaryDic setObject:@"F" forKey:@"1111"];
    
    if (binary.length % 4 != 0) {
        
        NSMutableString *mStr = [[NSMutableString alloc]init];;
        for (int i = 0; i < 4 - binary.length % 4; i++) {
            
            [mStr appendString:@"0"];
        }
        binary = [mStr stringByAppendingString:binary];
    }
    NSString *hex = @"";
    for (int i=0; i<binary.length; i+=4) {
        
        NSString *key = [binary substringWithRange:NSMakeRange(i, 4)];
        NSString *value = [binaryDic objectForKey:key];
        if (value) {
            
            hex = [hex stringByAppendingString:value];
        }
    }
    return hex;
}
//十六进制转二进制
- (NSString *)getBinaryByHex:(NSString *)hex {
    
    NSMutableDictionary *hexDic = [[NSMutableDictionary alloc] initWithCapacity:16];
    [hexDic setObject:@"0000" forKey:@"0"];
    [hexDic setObject:@"0001" forKey:@"1"];
    [hexDic setObject:@"0010" forKey:@"2"];
    [hexDic setObject:@"0011" forKey:@"3"];
    [hexDic setObject:@"0100" forKey:@"4"];
    [hexDic setObject:@"0101" forKey:@"5"];
    [hexDic setObject:@"0110" forKey:@"6"];
    [hexDic setObject:@"0111" forKey:@"7"];
    [hexDic setObject:@"1000" forKey:@"8"];
    [hexDic setObject:@"1001" forKey:@"9"];
    [hexDic setObject:@"1010" forKey:@"A"];
    [hexDic setObject:@"1011" forKey:@"B"];
    [hexDic setObject:@"1100" forKey:@"C"];
    [hexDic setObject:@"1101" forKey:@"D"];
    [hexDic setObject:@"1110" forKey:@"E"];
    [hexDic setObject:@"1111" forKey:@"F"];
    
    NSString *binary = @"";
    for (int i=0; i<[hex length]; i++) {
        
        NSString *key = [hex substringWithRange:NSMakeRange(i, 1)];
        NSString *value = [hexDic objectForKey:key.uppercaseString];
        if (value) {
            
            binary = [binary stringByAppendingString:value];
        }
    }
    return binary;
}
//二进制转十进制
- (NSInteger)getDecimalByBinary:(NSString *)binary {
    
    NSInteger decimal = 0;
    for (int i=0; i<binary.length; i++) {
        
        NSString *number = [binary substringWithRange:NSMakeRange(binary.length - i - 1, 1)];
        if ([number isEqualToString:@"1"]) {
            
            decimal += pow(2, i);
        }
    }
    return decimal;
}


//选择结果
- (void)pickerView:(UIView *)pickerView result:(NSString *)string
{
    NSLog(@"string = %@",string);
    [_btnL setTitle:string forState:UIControlStateNormal];
}

//回车键退出键盘
-(BOOL)textView:(UITextView *)textView shouldChangeTextInRange:(NSRange)range replacementText:(NSString *)text
{
    if ([text isEqualToString:@"\n"])
    {
        [textView resignFirstResponder];
        return NO;
    }
    return YES;
}


/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
