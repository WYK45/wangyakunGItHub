//
//  FirstViewController.m
//  ApeTools
//
//  Created by 王亚坤 on 2019/3/2.
//  Copyright © 2019 王亚坤. All rights reserved.
//

#import "FirstViewController.h"

@interface FirstViewController ()

@end

@implementation FirstViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    if ([[[ViewManager shareInstance] getPreferredLanguage] isEqualToString:@"zh-Hans-CN"])
    {
        [self setTopTitle:@"选择转换类型"];
    }
   else
   {
       [self setTopTitle:@"SelectType"];
   }
    [self setBackBtnHide:YES];
    
    [self.view addSubview:self.tab];
    
//   int isd=5000;
//    int sad = 1;
//    UIButton * btn1 = [self createBtn:CGRectMake(FitX(200), FitY(200*(sad++)), FitWidth(350), FitHeight(50)) title:@"base64" iconImage:nil backgroundImage:nil tag:isd++ textColor:[UIColor blackColor]];
//    [btn1 addTarget:self action:@selector(btn1Action) forControlEvents:UIControlEventTouchUpInside];
//    [self.view addSubview:btn1];
//
//    UIButton * btn2 = [self createBtn:CGRectMake(FitX(200), FitY(200*(sad++)), FitWidth(350), FitHeight(50)) title:@"url" iconImage:nil backgroundImage:nil tag:isd++ textColor:[UIColor blackColor]];
//    [btn2 addTarget:self action:@selector(btn2Action) forControlEvents:UIControlEventTouchUpInside];
//    [self.view addSubview:btn2];
//
//    UIButton * btn3 = [self createBtn:CGRectMake(FitX(200), FitY(200*(sad++)), FitWidth(350), FitHeight(50)) title:@"进制转换" iconImage:nil backgroundImage:nil tag:isd++ textColor:[UIColor blackColor]];
//    [btn3 addTarget:self action:@selector(btn3Action) forControlEvents:UIControlEventTouchUpInside];
//    [self.view addSubview:btn3];
//
//    UIButton * btn4 = [self createBtn:CGRectMake(FitX(200), FitY(200*(sad++)), FitWidth(350), FitHeight(50)) title:@"二维码" iconImage:nil backgroundImage:nil tag:isd++ textColor:[UIColor blackColor]];
//    [btn4 addTarget:self action:@selector(btn4Action) forControlEvents:UIControlEventTouchUpInside];
//    [self.view addSubview:btn4];
//
//    UIButton * btn5 = [self createBtn:CGRectMake(FitX(200), FitY(200*(sad++)), FitWidth(350), FitHeight(50)) title:@"色值" iconImage:nil backgroundImage:nil tag:isd++ textColor:[UIColor blackColor]];
//    [btn5 addTarget:self action:@selector(btn5Action) forControlEvents:UIControlEventTouchUpInside];
//    [self.view addSubview:btn5];
    
    
    
}


-(UITableView *)tab
{
    if (!_tab)
    {
        _tab = [[UITableView alloc]initWithFrame:CGRectMake(0,TopAndSystemHeight, ScreenWidth, ScreenHeight-TopAndSystemHeight)];
        _tab.delegate = self;
        _tab.dataSource = self;
    }
    return _tab;
}


-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return 5;
}
-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    UITableViewCell * cell = [tableView dequeueReusableCellWithIdentifier:@"cellid"];
    if (!cell)
    {
        cell = [[UITableViewCell alloc]initWithStyle:UITableViewCellStyleValue1 reuseIdentifier:@"cellid"];
        
    }
    if ([[[ViewManager shareInstance] getPreferredLanguage] isEqualToString:@"zh-Hans-CN"]) {
        switch (indexPath.row)
        {
            case 0:
                cell.imageView.image = [UIImage imageNamed:@"转换"];
                cell.textLabel.text = @"base64编码转换";
                break;
            case 1:
                cell.imageView.image = [UIImage imageNamed:@"url"];
                cell.textLabel.text = @"URL编码转换";
                break;
            case 2:
                cell.imageView.image = [UIImage imageNamed:@"禁止转换"];
                cell.textLabel.text = @"进制转换";
                break;
            case 3:
                cell.imageView.image = [UIImage imageNamed:@"二维码"];
                cell.textLabel.text = @"二维码生成";
                break;
            case 4:
                cell.imageView.image = [UIImage imageNamed:@"色值"];
                cell.textLabel.text = @"色值转换";
                break;
                
            default:
                break;
        }
    }
    else{
        switch (indexPath.row)
        {
            case 0:
                cell.imageView.image = [UIImage imageNamed:@"转换"];
                cell.textLabel.text = @"Base64Encoding";
                break;
            case 1:
                cell.imageView.image = [UIImage imageNamed:@"url"];
                cell.textLabel.text = @"URLEncoding";
                break;
            case 2:
                cell.imageView.image = [UIImage imageNamed:@"禁止转换"];
                cell.textLabel.text = @"BinarySystem";
                break;
            case 3:
                cell.imageView.image = [UIImage imageNamed:@"二维码"];
                cell.textLabel.text = @"Qr code";
                break;
            case 4:
                cell.imageView.image = [UIImage imageNamed:@"色值"];
                cell.textLabel.text = @"ColorSpace";
                break;
                
            default:
                break;
        }
    }
    
    return cell;
}
-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return FitHeight(200);
}
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    switch (indexPath.row)
    {
        case 0:
            [self btn1Action];
            break;
        case 1:
            [self btn2Action];
            break;
        case 2:
            [self btn3Action];
            break;
        case 3:
            [self btn4Action];
            break;
        case 4:
            [self btn5Action];
            break;
            
        default:
            break;
    }
    
}






-(void)btn1Action
{
    NSLog(@"1");
    Base64ViewController * base64 = [[Base64ViewController alloc]init];
    [[ViewManager shareInstance].NavigationController pushViewController:base64 animated:YES];
    
}
-(void)btn2Action
{
    UrlViewController * base64 = [[UrlViewController alloc]init];
    [[ViewManager shareInstance].NavigationController pushViewController:base64 animated:YES];
}
-(void)btn3Action
{
    BinaryViewController * base64 = [[BinaryViewController alloc]init];
    [[ViewManager shareInstance].NavigationController pushViewController:base64 animated:YES];
}
-(void)btn4Action
{
    QRCodeViewController * base64 = [[QRCodeViewController alloc]init];
    [[ViewManager shareInstance].NavigationController pushViewController:base64 animated:YES];
}
-(void)btn5Action
{
    ColorValueViewController * base64 = [[ColorValueViewController alloc]init];
    [[ViewManager shareInstance].NavigationController pushViewController:base64 animated:YES];
}


/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
