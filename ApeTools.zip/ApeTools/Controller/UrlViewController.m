//
//  UrlViewController.m
//  ApeTools
//
//  Created by 王亚坤 on 2019/3/2.
//  Copyright © 2019 王亚坤. All rights reserved.
//

#import "UrlViewController.h"

@interface UrlViewController ()

@end

@implementation UrlViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    if ([[[ViewManager shareInstance] getPreferredLanguage] isEqualToString:@"zh-Hans-CN"])
    {
        [self setTopTitle:@"Url编码转换"];
    }
    else
    {
        [self setTopTitle:@"Url Encoding"];
    }
    
    
    [self setBackBtnHide:NO];
    [self.view addSubview:self.tab];
}
-(UITextView *)textV1
{
    if (!_textV1)
    {
        _textV1 = [[UITextView alloc]initWithFrame:CGRectMake(FitX(20), FitHeight(20), FitWidth(710), FitHeight(375))];
        _textV1.layer.borderWidth = 1.0f;
        _textV1.layer.borderColor = [UIColor blackColor].CGColor;
        _textV1.delegate = self;
    }
    return _textV1;
}

-(UITextView *)textV2
{
    if (!_textV2)
    {
        _textV2 = [[UITextView alloc]initWithFrame:CGRectMake(FitX(20), FitHeight(20)+self.textV1.frame.size.height+FitHeight(150), FitWidth(710), FitHeight(375))];
        _textV2.layer.borderWidth = 1.0f;
        _textV2.layer.borderColor = [UIColor blackColor].CGColor;
        _textV2.delegate = self;
    }
    return _textV2;
}

-(UITableView *)tab{
    if (!_tab)
    {
        _tab = [[UITableView alloc]initWithFrame:CGRectMake(0,TopAndSystemHeight, ScreenWidth, ScreenHeight-TopAndSystemHeight)];
        _tab.delegate = self;
        _tab.dataSource = self;
    }
    return _tab;
}
-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return 1;
}
-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    UITableViewCell * cell = [tableView dequeueReusableCellWithIdentifier:@"cellid"];
    if (!cell)
    {
        cell = [[UITableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"cellid"];
        [cell addSubview:self.textV1];
        [cell addSubview:self.textV2];
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
        
        UIButton * btnL = [self createBtn:CGRectMake(FitX(200), FitY(445), FitWidth(150), FitHeight(50)) title:@"转换为UTF8" iconImage:nil backgroundImage:nil tag:6000 textColor:[UIColor whiteColor]];
        
        if ([[[ViewManager shareInstance] getPreferredLanguage] isEqualToString:@"zh-Hans-CN"])
        {
            [btnL setTitle:@"转换为UTF8" forState:UIControlStateNormal];
        }
        else
        {
            [btnL setTitle:@"To UTF8" forState:UIControlStateNormal];
        }
        
        [btnL setBackgroundColor:MainColor];
        btnL.layer.cornerRadius = 5.0f;
        [btnL addTarget:self action:@selector(btnLAction) forControlEvents:UIControlEventTouchUpInside];
        [cell addSubview:btnL];
        
        UIImageView * imagUP = [[UIImageView alloc]initWithFrame:CGRectMake(FitX(355), FitY(438), FitWidth(17), FitHeight(65))];
        imagUP.image = [UIImage imageNamed:@"箭头上"];
        [cell addSubview:imagUP];
        
        UIImageView * imagDOWN = [[UIImageView alloc]initWithFrame:CGRectMake(FitX(378), FitY(438), FitWidth(17), FitHeight(65))];
        imagDOWN.image = [UIImage imageNamed:@"箭头下"];
        [cell addSubview:imagDOWN];
        
        UIButton * btnR = [self createBtn:CGRectMake(FitX(400), FitY(445), FitWidth(180), FitHeight(50)) title:@"转换为URL码" iconImage:nil backgroundImage:nil tag:6000 textColor:[UIColor whiteColor]];
        
        if ([[[ViewManager shareInstance] getPreferredLanguage] isEqualToString:@"zh-Hans-CN"])
        {
            [btnR setTitle:@"转换为URL" forState:UIControlStateNormal];
        }
        else
        {
            [btnR setTitle:@"To URL code" forState:UIControlStateNormal];
        }
        
        [btnR setBackgroundColor:MainColor];
        btnR.layer.cornerRadius = 5.0f;
        [btnR addTarget:self action:@selector(btnRAction) forControlEvents:UIControlEventTouchUpInside];
        [cell addSubview:btnR];
        
        
        UIButton * ShareBtn = [self createBtn:CGRectMake(FitX(205), FitY(960), FitWidth(340), FitHeight(65)) title:@"分享并拷贝到粘贴板" iconImage:nil backgroundImage:nil tag:60050 textColor:[UIColor whiteColor]];
        
        if ([[[ViewManager shareInstance] getPreferredLanguage] isEqualToString:@"zh-Hans-CN"])
        {
            [ShareBtn setTitle:@"分享并拷贝到粘贴板" forState:UIControlStateNormal];
        }
        else
        {
            [ShareBtn setTitle:@"Share" forState:UIControlStateNormal];
        }
        
        [ShareBtn setBackgroundColor:MainColor];
        ShareBtn.titleLabel.textAlignment = NSTextAlignmentCenter;
        ShareBtn.layer.cornerRadius = 5.0f;
        [ShareBtn addTarget:self action:@selector(ShareAction) forControlEvents:UIControlEventTouchUpInside];
        
        [cell addSubview:ShareBtn];
        
    }
    return cell;
}
-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return (FitHeight(750)*2)*1.2;
}

-(void)btnLAction
{
    self.textV1.text = [self.textV2.text stringByReplacingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
}
-(void)btnRAction
{
    self.textV2.text = AFPercentEscapedStringFromString(_textV1.text);
}
-(void)ShareAction
{
    UIPasteboard *pasteboard = [UIPasteboard generalPasteboard];
    pasteboard.string = _textV2.text;
    if (![_textV2.text  isEqual:@""])
    {
        NSArray *activityItems = @[self.textV2.text];
        UIActivityViewController *activityVC = [[UIActivityViewController alloc]initWithActivityItems:activityItems applicationActivities:nil];
        
        [self presentViewController:activityVC animated:YES completion:nil];
    }
    else{
        if ([[[ViewManager shareInstance] getPreferredLanguage] isEqualToString:@"zh-Hans-CN"])
        {
            [MyProgressHUD showErrorWithStatus:@"没有内容可以分享"];
        }
        else
        {
            [MyProgressHUD showErrorWithStatus:@"No content to share"];
        }
    }
}


NSString * AFPercentEscapedStringFromString(NSString *string) {
    static NSString * const kAFCharactersGeneralDelimitersToEncode = @":#[]@"; // does not include "?" or "/" due to RFC 3986 - Section 3.4
    static NSString * const kAFCharactersSubDelimitersToEncode = @"!$&'()*+,;=";
    
    NSMutableCharacterSet * allowedCharacterSet = [[NSCharacterSet URLQueryAllowedCharacterSet] mutableCopy];
    [allowedCharacterSet removeCharactersInString:[kAFCharactersGeneralDelimitersToEncode stringByAppendingString:kAFCharactersSubDelimitersToEncode]];
    
    // FIXME: https://github.com/AFNetworking/AFNetworking/pull/3028
    // return [string stringByAddingPercentEncodingWithAllowedCharacters:allowedCharacterSet];
    
    static NSUInteger const batchSize = 50;
    
    NSUInteger index = 0;
    NSMutableString *escaped = @"".mutableCopy;
    
    while (index < string.length) {
        NSUInteger length = MIN(string.length - index, batchSize);
        NSRange range = NSMakeRange(index, length);
        
        // To avoid breaking up character sequences such as 👴🏻👮🏽
        range = [string rangeOfComposedCharacterSequencesForRange:range];
        
        NSString *substring = [string substringWithRange:range];
        NSString *encoded = [substring stringByAddingPercentEncodingWithAllowedCharacters:allowedCharacterSet];
        [escaped appendString:encoded];
        
        index += range.length;
    }
    
    return escaped;
}


//回车键退出键盘
-(BOOL)textView:(UITextView *)textView shouldChangeTextInRange:(NSRange)range replacementText:(NSString *)text
{
    if ([text isEqualToString:@"\n"])
    {
        [textView resignFirstResponder];
        return NO;
    }
    return YES;
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
