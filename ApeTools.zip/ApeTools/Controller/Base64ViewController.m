//
//  Base64ViewController.m
//  ApeTools
//
//  Created by 王亚坤 on 2019/3/2.
//  Copyright © 2019 王亚坤. All rights reserved.
//

#import "Base64ViewController.h"
#import "MyProgressHUD.h"
@interface Base64ViewController ()

@end

@implementation Base64ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    if ([[[ViewManager shareInstance] getPreferredLanguage] isEqualToString:@"zh-Hans-CN"])
    {
        [self setTopTitle:@"base64编码转换"];
    }
    else
    {
        [self setTopTitle:@"Base64Encoding"];
    }
    [self setBackBtnHide:NO];
    [self.view addSubview:self.tab];
    
    
}

-(UIImageView *)imageV1
{
    if (!_imageV1)
    {
        _imageV1 = [[UIImageView alloc]initWithFrame:CGRectMake(FitX(20), FitHeight(20), FitWidth(710), FitHeight(750))];
        _imageV1.layer.borderWidth = 1.0f;
        _imageV1.layer.borderColor = [UIColor blackColor].CGColor;
        _imageV1.backgroundColor = [UIColor colorWithRed:1.0 green:1.0 blue:1.0 alpha:0];
        _imageV1.userInteractionEnabled = YES;
        UITapGestureRecognizer *singleTap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(handleSingleTap:)];
        [_imageV1 addGestureRecognizer:singleTap];
    }
    return _imageV1;
}

-(UITextView *)textV2
{
    if (!_textV2)
    {
        _textV2 = [[UITextView alloc]initWithFrame:CGRectMake(FitX(20), FitHeight(20)+self.imageV1.frame.size.height+FitHeight(150), FitWidth(710), FitHeight(375))];
        _textV2.layer.borderWidth = 1.0f;
        _textV2.layer.borderColor = [UIColor blackColor].CGColor;
        _textV2.delegate = self;
        
    }
    return _textV2;
}

-(UITableView *)tab{
    if (!_tab)
    {
        _tab = [[UITableView alloc]initWithFrame:CGRectMake(0,TopAndSystemHeight, ScreenWidth, ScreenHeight-TopAndSystemHeight)];
        _tab.delegate = self;
        _tab.dataSource = self;
    }
    return _tab;
}
-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return 1;
}
-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    UITableViewCell * cell = [tableView dequeueReusableCellWithIdentifier:@"cellid"];
    if (!cell)
    {
        cell = [[UITableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"cellid"];
        UILabel * lab = [[UILabel alloc]initWithFrame:CGRectMake(FitX(0), FitY(300), ScreenWidth, FitHeight(50))];
        
        if ([[[ViewManager shareInstance] getPreferredLanguage] isEqualToString:@"zh-Hans-CN"])
        {
            lab.text = @"点击此处选择你要转换的图片。。。";
        }
        else
        {
            lab.text = @"Click here to start";
        }
        
        
        
        lab.textAlignment = NSTextAlignmentCenter;
        [cell addSubview:lab];
        
        [cell addSubview:self.imageV1];
        [cell addSubview:self.textV2];
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
        
        
        UIButton * btnL = [self createBtn:CGRectMake(FitX(200), FitY(820), FitWidth(150), FitHeight(50)) title:@"转换为图片" iconImage:nil backgroundImage:nil tag:6000 textColor:[UIColor whiteColor]];
        
        if ([[[ViewManager shareInstance] getPreferredLanguage] isEqualToString:@"zh-Hans-CN"])
        {
            [btnL setTitle:@"转换为图片" forState:UIControlStateNormal];
        }
        else
        {
           [btnL setTitle:@"To image" forState:UIControlStateNormal];
        }
        
        
        [btnL setBackgroundColor:MainColor];
        btnL.layer.cornerRadius = 5.0f;
        [btnL addTarget:self action:@selector(btnLAction) forControlEvents:UIControlEventTouchUpInside];
        [cell addSubview:btnL];
        
        UIImageView * imagUP = [[UIImageView alloc]initWithFrame:CGRectMake(FitX(355), FitY(813), FitWidth(17), FitHeight(65))];
        imagUP.image = [UIImage imageNamed:@"箭头上"];
        [cell addSubview:imagUP];
        
        UIImageView * imagDOWN = [[UIImageView alloc]initWithFrame:CGRectMake(FitX(378), FitY(813), FitWidth(17), FitHeight(65))];
        imagDOWN.image = [UIImage imageNamed:@"箭头下"];
        [cell addSubview:imagDOWN];
        
        
        UIButton * btnR = [self createBtn:CGRectMake(FitX(400), FitY(820), FitWidth(180), FitHeight(50)) title:@"转换为Base64" iconImage:nil backgroundImage:nil tag:6000 textColor:[UIColor whiteColor]];
        
        if ([[[ViewManager shareInstance] getPreferredLanguage] isEqualToString:@"zh-Hans-CN"])
        {
            [btnR setTitle:@"转换为Base64" forState:UIControlStateNormal];
        }
        else
        {
            [btnR setTitle:@"To Base64" forState:UIControlStateNormal];
        }
        
        
        [btnR setBackgroundColor:MainColor];
         btnR.layer.cornerRadius = 5.0f;
        [btnR addTarget:self action:@selector(btnRAction) forControlEvents:UIControlEventTouchUpInside];
        [cell addSubview:btnR];
        
        
        UIButton * ShareBtn = [self createBtn:CGRectMake(FitX(205), FitY(1343), FitWidth(340), FitHeight(65)) title:@"分享并拷贝到粘贴板" iconImage:nil backgroundImage:nil tag:60050 textColor:[UIColor whiteColor]];
        
        if ([[[ViewManager shareInstance] getPreferredLanguage] isEqualToString:@"zh-Hans-CN"])
        {
            [ShareBtn setTitle:@"分享并拷贝到粘贴板" forState:UIControlStateNormal];
        }
        else
        {
            [ShareBtn setTitle:@"Share" forState:UIControlStateNormal];
        }
        
        
        
        [ShareBtn setBackgroundColor:MainColor];
        ShareBtn.titleLabel.textAlignment = NSTextAlignmentCenter;
        ShareBtn.layer.cornerRadius = 5.0f;
        [ShareBtn addTarget:self action:@selector(ShareAction) forControlEvents:UIControlEventTouchUpInside];
        
        [cell addSubview:ShareBtn];
        
        
    }
    return cell;
}
-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return (FitHeight(750)*2)*1.4;
}
- (void)handleSingleTap:(UIGestureRecognizer *)gestureRecognizer{
    //do something....
    [ZZQAvatarPicker startSelected:^(UIImage * _Nonnull image) {
        self->_imageV1.image = image;
        //uiimage转base64
       
        //base64转uiimage
        
    }];
}

-(void)btnAction
{
   _imageV1.image = NULL;
    NSData *data = [[NSData alloc]initWithBase64EncodedString:_textV2.text options:NSDataBase64DecodingIgnoreUnknownCharacters];
    _imageV1.image = [UIImage imageWithData:data];
    UIPasteboard *pasteboard = [UIPasteboard generalPasteboard];
    pasteboard.string = _textV2.text;
    NSLog(@"pasteboard = %@",pasteboard.string);
}


-(void)btnLAction
{ [MyProgressHUD show];
    
    _imageV1.image = NULL;
    NSData *data = [[NSData alloc]initWithBase64EncodedString:_textV2.text options:NSDataBase64DecodingIgnoreUnknownCharacters];
    _imageV1.image = [UIImage imageWithData:data];
    UIPasteboard *pasteboard = [UIPasteboard generalPasteboard];
    pasteboard.string = _textV2.text;
//    NSLog(@"pasteboard = %@",pasteboard.string);
    [MyProgressHUD dismiss];
    
}
-(void)btnRAction
{
    NSLog(@"123");
    [MyProgressHUD show];
    
    dispatch_queue_t queue = dispatch_queue_create("net.bujige.testQueue", DISPATCH_QUEUE_SERIAL);
    UIImage * ima = self->_imageV1.image;
    
    dispatch_async(queue, ^{
        NSString *encodedImageStr = [UIImagePNGRepresentation(ima) base64EncodedStringWithOptions:NSDataBase64EncodingEndLineWithLineFeed];
        
        [[NSOperationQueue mainQueue] addOperationWithBlock:^{
            self->_textV2.text = encodedImageStr;
            [MyProgressHUD dismiss];
        }];
    });
    
    
    
}
-(void)ShareAction
{
    UIPasteboard *pasteboard = [UIPasteboard generalPasteboard];
    pasteboard.string = _textV2.text;
    if (![_textV2.text  isEqual:@""])
    {
        NSArray *activityItems = @[self.textV2.text];
        UIActivityViewController *activityVC = [[UIActivityViewController alloc]initWithActivityItems:activityItems applicationActivities:nil];
        
        [self presentViewController:activityVC animated:YES completion:nil];
    }
    else{
        if ([[[ViewManager shareInstance] getPreferredLanguage] isEqualToString:@"zh-Hans-CN"])
        {
            [MyProgressHUD showErrorWithStatus:@"没有内容可以分享"];
        }
        else
        {
            [MyProgressHUD showErrorWithStatus:@"No content to share"];
        }
        
        
    }
    
}

//回车键退出键盘
-(BOOL)textView:(UITextView *)textView shouldChangeTextInRange:(NSRange)range replacementText:(NSString *)text
{
    if ([text isEqualToString:@"\n"])
    {
        [textView resignFirstResponder];
        return NO;
    }
    return YES;
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
