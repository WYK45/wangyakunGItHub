//
//  PickerModel.h
//  Test
//
//  Created by K.O on 2018/7/20.
//  Copyright © 2018年 rela. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface PickerModel : NSObject

@property(nonatomic,strong) NSArray *cities;
@property(nonatomic,strong) NSString *province;



@end
