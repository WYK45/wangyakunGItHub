//
//  ViewManager.h
//  projectBase
//
//  Created by chenjianying on 15-11-14.
//  Copyright (c) 2015年 chenjianying. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
@interface ViewManager : NSObject
{
@private
    UINavigationController *_navigationController;
}

@property (atomic, readonly) UINavigationController *NavigationController;

+(ViewManager*)shareInstance;
-(NSString*)getPreferredLanguage;
-(void)toMainPlat;

@end
