//
//  AppDelegate.h
//  CharacterPicker
//
//  Created by 王亚坤 on 2019/2/18.
//  Copyright © 2019 王亚坤. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "TransmissionTool.h"
#import "ViewManager.h"
@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

