//
//  TransmissionTool.h
//  CharacterPicker
//
//  Created by 王亚坤 on 2019/2/19.
//  Copyright © 2019 王亚坤. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "AFNetworking.h"
#import "MyProgressHUD.h"
#import "TheResultModel.h"
NS_ASSUME_NONNULL_BEGIN

@interface TransmissionTool : NSObject

@property (nonatomic,strong)  __block NSString * token;
@property (nonatomic,strong) AFHTTPSessionManager * manger;


+(TransmissionTool*)shareInstance;
-(void)getToken:(void (^)(NSString * Token))blockName;
-(void)handwritingTextFromImage:(UIImage *)image handler:(void (^)(NSString * words))blockName;//手写体识别
-(void)general_basicTextFromImage:(UIImage *)image handler:(void (^)(NSString * words))blockName;//通用文字识别
-(void)idcardTextFromImage:(UIImage *)image handler:(void (^)(NSString * words))blockName;//身份证识别
-(void)bankcardTextFromImage:(UIImage *)image handler:(void (^)(NSString * words))blockName;//银行卡识别
-(void)form_ocrTextFromImage:(UIImage *)image handler:(void (^)(NSString * words))blockName;//表格识别
-(void)train_ticketTextFromImage:(UIImage *)image handler:(void (^)(NSString * words))blockName;//火车票识别
-(void)webimageTextFromImage:(UIImage *)image handler:(void (^)(NSString * words))blockName;//网络图片识别
-(void)vat_invoiceTextFromImage:(UIImage *)image handler:(void (^)(NSString * words))blockName;//发票识别

@end

NS_ASSUME_NONNULL_END
