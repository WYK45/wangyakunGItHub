//
//  TransmissionTool.m
//  CharacterPicker
//
//  Created by 王亚坤 on 2019/2/19.
//  Copyright © 2019 王亚坤. All rights reserved.
//

#import "TransmissionTool.h"

@implementation TransmissionTool
+(TransmissionTool *)shareInstance
{
    static TransmissionTool * singletonManager = nil;
    @synchronized(self){
        if (!singletonManager) {
            singletonManager = [[TransmissionTool alloc]init];
        }
    }
    return singletonManager;
}


-(void)getToken:(void (^)(NSString * _Nonnull))blockName
{
    
    [MyProgressHUD showWithMaskType:MyProgressHUDMaskTypeBlack];        self->_manger = [[AFHTTPSessionManager alloc]init];
    
    _manger.responseSerializer.acceptableContentTypes = [NSSet setWithObjects:@"application/json", @"text/json", @"text/javascript",@"text/html",@"text/plain",nil];
        NSMutableDictionary * param1 = [[NSMutableDictionary alloc]initWithObjectsAndKeys:@"client_credentials",@"grant_type",@"m10hIVZxebF2Gc1doxgTn1xS",@"client_id",@"AksEw0ZdGtAYVgbwrRbedjHiV937xmIV",@"client_secret",nil];
        self->_token = [[NSString alloc]init];

        [self->_manger POST:@"https://aip.baidubce.com/oauth/2.0/token" parameters:param1 progress:nil success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
            self->_token = [responseObject valueForKey:@"access_token"];
            blockName(self->_token);
        } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
            NSLog(@"error1 = %@",error);

        }];
}

-(void)handwritingTextFromImage:(UIImage *)image handler:(void (^)(NSString * _Nonnull))blockName
{//手写体识别
    if ([[[TheResultModel shareInstance] getPreferredLanguage] isEqualToString:@"zh-Hans-CN"]) {
        [MyProgressHUD showWithStatus:@"正在识别"];
    }
    else{
        [MyProgressHUD showWithStatus:@"Are extracting"];
    }
    
    NSString *encodedImageStr = [UIImagePNGRepresentation(image) base64EncodedStringWithOptions:NSDataBase64EncodingEndLineWithLineFeed];
    
    NSMutableDictionary * param2 = [[NSMutableDictionary alloc]initWithObjectsAndKeys:_token,@"access_token",@"application/x-www-form-urlencoded",@"Content-Type",encodedImageStr,@"image",@"BASE64",@"image_type",@"gropu001",@"group_id",@"0002",@"user_id", nil];
    //    [parama setObject:urlencode forKey:@"application/x-www-form-urlencoded"];
    
    [_manger POST:@"https://aip.baidubce.com/rest/2.0/ocr/v1/handwriting" parameters:param2 progress:nil success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
        [MyProgressHUD dismiss];
        NSMutableString * mustr = [NSMutableString new];
        NSLog(@"responseObject = %@",responseObject);
        for (NSDictionary * dic in [responseObject valueForKey:@"words_result"])
        {
            [mustr appendFormat:@"%@\n",[dic valueForKey:@"words"]];
        }
        blockName(mustr);
        
    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
        NSLog(@"error = %@",error);
        
    }];
}


-(void)general_basicTextFromImage:(UIImage *)image handler:(void (^)(NSString * words))blockName
{//通用文字识别
    if ([[[TheResultModel shareInstance] getPreferredLanguage] isEqualToString:@"zh-Hans-CN"]) {
        [MyProgressHUD showWithStatus:@"正在识别"];
    }
    else{
        [MyProgressHUD showWithStatus:@"Are extracting"];
    }
    
    NSString *encodedImageStr = [UIImagePNGRepresentation(image) base64EncodedStringWithOptions:NSDataBase64EncodingEndLineWithLineFeed];
    
    NSMutableDictionary * param2 = [[NSMutableDictionary alloc]initWithObjectsAndKeys:_token,@"access_token",@"application/x-www-form-urlencoded",@"Content-Type",encodedImageStr,@"image",@"BASE64",@"image_type",@"gropu001",@"group_id",@"0002",@"user_id", nil];
    //    [parama setObject:urlencode forKey:@"application/x-www-form-urlencoded"];
    
    [_manger POST:@"https://aip.baidubce.com/rest/2.0/ocr/v1/general_basic" parameters:param2 progress:nil success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
        [MyProgressHUD dismiss];
        NSMutableString * mustr = [NSMutableString new];
//        NSLog(@"responseObject = %@",responseObject);
        for (NSDictionary * dic in [responseObject valueForKey:@"words_result"])
        {
            [mustr appendFormat:@"%@\n",[dic valueForKey:@"words"]];
        }
        blockName(mustr);
        
    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
        NSLog(@"error = %@",error);
        
    }];
    
}

-(void)idcardTextFromImage:(UIImage *)image handler:(void (^)(NSString * words))blockName
{//身份证识别
    if ([[[TheResultModel shareInstance] getPreferredLanguage] isEqualToString:@"zh-Hans-CN"]) {
        [MyProgressHUD showWithStatus:@"正在识别"];
    }
    else{
        [MyProgressHUD showWithStatus:@"Are extracting"];
    }
    
    NSString *encodedImageStr = [UIImagePNGRepresentation(image) base64EncodedStringWithOptions:NSDataBase64EncodingEndLineWithLineFeed];
    
    NSMutableDictionary * param2 = [[NSMutableDictionary alloc]initWithObjectsAndKeys:_token,@"access_token",@"application/x-www-form-urlencoded",@"Content-Type",@"front",@"id_card_side",encodedImageStr,@"image",@"BASE64",@"image_type",@"gropu001",@"group_id",@"0002",@"user_id", nil];
    //    [parama setObject:urlencode forKey:@"application/x-www-form-urlencoded"];
    
    [_manger POST:@"https://aip.baidubce.com/rest/2.0/ocr/v1/idcard" parameters:param2 progress:nil success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
        [MyProgressHUD dismiss];
        NSMutableString * mustr = [NSMutableString new];
        NSDictionary * dic = [responseObject objectForKey:@"words_result"];
        NSArray * arr1 = [dic allKeys];
        
        for (NSString * str in arr1)
        {
            NSDictionary * dict = [dic valueForKey:str];
            
            [mustr appendFormat:@"%@:%@\n",str,[dict valueForKey:@"words"]];
        }
       NSLog(@"mustr = %@",mustr);
        blockName(mustr);
        
    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
        NSLog(@"error = %@",error);
        
    }];
}

-(void)bankcardTextFromImage:(UIImage *)image handler:(void (^)(NSString * words))blockName
{//银行卡识别
    if ([[[TheResultModel shareInstance] getPreferredLanguage] isEqualToString:@"zh-Hans-CN"]) {
        [MyProgressHUD showWithStatus:@"正在识别"];
    }
    else{
        [MyProgressHUD showWithStatus:@"Are extracting"];
    }
    
    NSString *encodedImageStr = [UIImagePNGRepresentation(image) base64EncodedStringWithOptions:NSDataBase64EncodingEndLineWithLineFeed];
    
    NSMutableDictionary * param2 = [[NSMutableDictionary alloc]initWithObjectsAndKeys:_token,@"access_token",@"application/x-www-form-urlencoded",@"Content-Type",encodedImageStr,@"image",@"BASE64",@"image_type",@"gropu001",@"group_id",@"0002",@"user_id", nil];
    //    [parama setObject:urlencode forKey:@"application/x-www-form-urlencoded"];
    
    [_manger POST:@"https://aip.baidubce.com/rest/2.0/ocr/v1/bankcard" parameters:param2 progress:nil success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
        [MyProgressHUD dismiss];
        NSMutableString * mustr = [NSMutableString new];
        NSLog(@"responseObject = %@",responseObject);
        NSDictionary * dic = [responseObject valueForKey:@"result"];
            NSLog(@"dic = %@",dic);
            [mustr appendFormat:@"card_number：%@\n",[dic valueForKey:@"bank_card_number"]];
            [mustr appendFormat:@"card_type：%@\n",[dic valueForKey:@"bank_card_type"]];
            [mustr appendFormat:@"bank_name：%@\n",[dic valueForKey:@"bank_name"]];
            [mustr appendFormat:@"valid_date：%@\n",[dic valueForKey:@"valid_date"]];
        blockName(mustr);
        
    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
        NSLog(@"error = %@",error);
        
    }];
    
}
-(void)form_ocrTextFromImage:(UIImage *)image handler:(void (^)(NSString * words))blockName
{//表格识别
    
    
    
}
-(void)train_ticketTextFromImage:(UIImage *)image handler:(void (^)(NSString * words))blockName
{//火车票识别
    if ([[[TheResultModel shareInstance] getPreferredLanguage] isEqualToString:@"zh-Hans-CN"]) {
        [MyProgressHUD showWithStatus:@"正在识别"];
    }
    else{
        [MyProgressHUD showWithStatus:@"Are extracting"];
    }
    
    NSString *encodedImageStr = [UIImagePNGRepresentation(image) base64EncodedStringWithOptions:NSDataBase64EncodingEndLineWithLineFeed];
    
    NSMutableDictionary * param2 = [[NSMutableDictionary alloc]initWithObjectsAndKeys:_token,@"access_token",@"application/x-www-form-urlencoded",@"Content-Type",encodedImageStr,@"image",@"BASE64",@"image_type",@"gropu001",@"group_id",@"0002",@"user_id", nil];
    //    [parama setObject:urlencode forKey:@"application/x-www-form-urlencoded"];
    
    [_manger POST:@"https://aip.baidubce.com/rest/2.0/ocr/v1/train_ticket" parameters:param2 progress:nil success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
        [MyProgressHUD dismiss];
        NSMutableString * mustr = [NSMutableString new];
        NSLog(@"responseObject = %@",responseObject);
        NSDictionary * dic = [responseObject valueForKey:@"words_result"];
         [mustr appendFormat:@"date：%@\n",[dic valueForKey:@"date"]];
         [mustr appendFormat:@"destination_station：%@\n",[dic valueForKey:@"destination_station"]];
         [mustr appendFormat:@"name：%@\n",[dic valueForKey:@"name"]];
         [mustr appendFormat:@"seat_category：%@\n",[dic valueForKey:@"seat_category"]];
         [mustr appendFormat:@"starting_station：%@\n",[dic valueForKey:@"starting_station"]];
         [mustr appendFormat:@"ticket_num：%@\n",[dic valueForKey:@"ticket_num"]];
         [mustr appendFormat:@"ticket_rates：%@\n",[dic valueForKey:@"ticket_rates"]];
         [mustr appendFormat:@"train_num：%@\n",[dic valueForKey:@"train_num"]];
        blockName(mustr);
        
    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
        NSLog(@"error = %@",error);
        
    }];
}

-(void)webimageTextFromImage:(UIImage *)image handler:(void (^)(NSString * words))blockName
{//网络图片识别
    if ([[[TheResultModel shareInstance] getPreferredLanguage] isEqualToString:@"zh-Hans-CN"]) {
        [MyProgressHUD showWithStatus:@"正在识别"];
    }
    else{
        [MyProgressHUD showWithStatus:@"Are extracting"];
    }
    
    
    NSString *encodedImageStr = [UIImagePNGRepresentation(image) base64EncodedStringWithOptions:NSDataBase64EncodingEndLineWithLineFeed];
    
    NSMutableDictionary * param2 = [[NSMutableDictionary alloc]initWithObjectsAndKeys:_token,@"access_token",@"application/x-www-form-urlencoded",@"Content-Type",encodedImageStr,@"image",@"BASE64",@"image_type",@"gropu001",@"group_id",@"0002",@"user_id", nil];
    //[parama setObject:urlencode forKey:@"application/x-www-form-urlencoded"];
    
    [_manger POST:@"https://aip.baidubce.com/rest/2.0/ocr/v1/webimage" parameters:param2 progress:nil success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
        [MyProgressHUD dismiss];
        NSMutableString * mustr = [NSMutableString new];
        NSLog(@"responseObject = %@",responseObject);
        for (NSDictionary * dic in [responseObject valueForKey:@"words_result"])
        {
            [mustr appendString:[dic valueForKey:@"words"]];
        }
        blockName(mustr);
        
    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
        NSLog(@"error = %@",error);
        
    }];
}
-(void)vat_invoiceTextFromImage:(UIImage *)image handler:(void (^)(NSString * words))blockName
{//发票识别
    if ([[[TheResultModel shareInstance] getPreferredLanguage] isEqualToString:@"zh-Hans-CN"]) {
        [MyProgressHUD showWithStatus:@"正在识别"];
    }
    else{
        [MyProgressHUD showWithStatus:@"Are extracting"];
    }
    
    NSString *encodedImageStr = [UIImagePNGRepresentation(image) base64EncodedStringWithOptions:NSDataBase64EncodingEndLineWithLineFeed];
    
    NSMutableDictionary * param2 = [[NSMutableDictionary alloc]initWithObjectsAndKeys:_token,@"access_token",@"application/x-www-form-urlencoded",@"Content-Type",encodedImageStr,@"image",nil];
    //    [parama setObject:urlencode forKey:@"application/x-www-form-urlencoded"];
    
    [_manger POST:@"https://aip.baidubce.com/rest/2.0/ocr/v1/vat_invoice" parameters:param2 progress:nil success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
        [MyProgressHUD dismiss];
        NSMutableString * mustr = [NSMutableString new];
        NSLog(@"responseObject = %@",responseObject);
        
        if ([[[TheResultModel shareInstance] getPreferredLanguage] isEqualToString:@"zh-Hans-CN"]) {
            [MyProgressHUD showErrorWithStatus:@"识别错误，请稍后再试" duration:2.0];
        }
        else{
            [MyProgressHUD showErrorWithStatus:@"Error detected. Please try again later" duration:2.0];
        }
        
        [mustr appendFormat:@"%@error_code:%@\n",[responseObject valueForKey:@"error_msg"],[responseObject valueForKey:@"error_code"]];
        blockName(mustr);
        
    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
        NSLog(@"error = %@",error);
        
    }];
}
@end
