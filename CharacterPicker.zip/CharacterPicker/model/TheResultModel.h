//
//  TheResultModel.h
//  CharacterPicker
//
//  Created by 王亚坤 on 2019/2/21.
//  Copyright © 2019 王亚坤. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
NS_ASSUME_NONNULL_BEGIN

@interface TheResultModel : NSObject
@property (nonatomic,strong) NSString * detail;
@property (nonatomic,strong) NSString * data;
@property (nonatomic,strong) UIImage * imag;

+(TheResultModel*)shareInstance;
-(NSString*)getPreferredLanguage;
@end

NS_ASSUME_NONNULL_END
