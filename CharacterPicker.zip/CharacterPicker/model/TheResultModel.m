//
//  TheResultModel.m
//  CharacterPicker
//
//  Created by 王亚坤 on 2019/2/21.
//  Copyright © 2019 王亚坤. All rights reserved.
//

#import "TheResultModel.h"

@implementation TheResultModel
+(TheResultModel*)shareInstance
{
    static TheResultModel * singletonManager = nil;
    @synchronized(self){
        if (!singletonManager) {
            singletonManager = [[TheResultModel alloc]init];
        }
    }
    return singletonManager;

}
-(TheResultModel *)init
{
    self = [super init];
    if (self)
    {
        self.imag = [[UIImage alloc]init];
        self.detail = [[NSString alloc]init];
        self.data = [[NSString alloc]init];
    }
    return self;
}

//自定义对象转换NSData
- (void)encodeWithCoder:(NSCoder *)aCoder{
    
    [aCoder encodeObject:self.detail forKey:@"text"];
    [aCoder encodeObject:self.imag forKey:@"image"];
    [aCoder encodeObject:self.data forKey:@"data"];
    
    
}

- (instancetype)initWithCoder:(NSCoder *)aDecoder{
    
    if (self = [super init]) {
        self.detail = [aDecoder decodeObjectForKey:@"text"];
        self.imag = [aDecoder decodeObjectForKey:@"image"];
        self.data = [aDecoder decodeObjectForKey:@"data"];
    }
    return self;
}

//判断语言类别
-(NSString*)getPreferredLanguage

{
    
    NSUserDefaults * defaults = [NSUserDefaults standardUserDefaults];
    
    NSArray * allLanguages = [defaults objectForKey:@"AppleLanguages"];
    
    NSString * preferredLang = [allLanguages objectAtIndex:0];
    
    NSLog(@"当前语言:%@", preferredLang);
    
    return preferredLang;
    
}

@end
