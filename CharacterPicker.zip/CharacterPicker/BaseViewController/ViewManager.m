//
//  ViewManager.m
//  projectBase
//
//  Created by chenjianying on 15-11-14.
//  Copyright (c) 2015年 chenjianying. All rights reserved.
//

#import "ViewManager.h"
#import "MeumViewController.h"





@implementation ViewManager

static ViewManager* mInstance;

@synthesize NavigationController = _navigationController;


+ (ViewManager*)shareInstance
{
    if (nil == mInstance)
    {
        mInstance = [[ViewManager alloc] init];
    }
    
    return mInstance;
}


-(id)init
{
    self = [super init];
    if(self != nil)
    {
        MeumViewController * uiVc = [[MeumViewController alloc]init];;
        _navigationController = [[UINavigationController alloc] initWithRootViewController:uiVc];
//        _navigationController = [[UINavigationController alloc] initWithRootViewController:[self createYMTTabBarController]];
    }
    
    
    _navigationController.navigationBar.hidden = YES;
    _navigationController.interactivePopGestureRecognizer.enabled = YES;
    
    
    return self;
}

-(NSString*)getPreferredLanguage

{
    
    NSUserDefaults * defaults = [NSUserDefaults standardUserDefaults];
    
    NSArray * allLanguages = [defaults objectForKey:@"AppleLanguages"];
    
    NSString * preferredLang = [allLanguages objectAtIndex:0];
    
    NSLog(@"当前语言:%@", preferredLang);
    
    return preferredLang;
    
}



-(void)toMainPlat
{
//    [_navigationController pushViewController:[self createYMTTabBarController] animated:YES];
}


@end
