//
//  TopBarView.m
//  projectBase
//
//  Created by chenjianying on 14-9-11.
//  Copyright (c) 2015年 chenjianying. All rights reserved.
//

#import "TopBarView.h"
#import "sizeHeader.h"

#define TitleLabWidth  150
#define LINE           151

@implementation TopBarView

-(void)onchangeskin
{
    bgView.backgroundColor = MainColor;
}

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        
        bgView = [[UIImageView alloc] initWithFrame:CGRectMake(0, 0, ScreenWidth, TopAndSystemHeight)];
        bgView.userInteractionEnabled = YES;
        bgView.backgroundColor = MainColor;
        
        backBtn = [UIButton buttonWithType:UIButtonTypeCustom];
        backBtn.frame =CGRectMake(FitX(25), FitY(60), FitWidth(68), FitWidth(48));
        [backBtn setImage:[UIImage imageNamed:@"leftArrowheadIcon.png"] forState:UIControlStateNormal];
        [backBtn setImageEdgeInsets:UIEdgeInsetsMake(0, 0, 0, FitWidth(40))];
        [backBtn addTarget:self action:@selector(btnAction:) forControlEvents:UIControlEventTouchUpInside];
        [bgView addSubview:backBtn];
        
        titleLab = [[UILabel alloc] initWithFrame:CGRectMake(50, FitY(bgView.frame.size.height), ScreenWidth-100, 20)];
        titleLab.textColor = [UIColor blackColor];
        titleLab.textAlignment = NSTextAlignmentCenter;
        titleLab.backgroundColor = [UIColor clearColor];
        titleLab.font = [UIFont systemFontOfSize:17.0];
        [bgView addSubview:titleLab];
        
        UIView *line = [[UIView alloc] initWithFrame:CGRectMake(0, bgView.frame.size.height-1, ScreenWidth, 1)];
        line.tag = LINE;
        line.alpha = .4;
        line.backgroundColor = UIColorRGB(220);
        [bgView addSubview:line];
        
        [self addSubview:bgView];
        
        
        
    }
    return self;
}

-(void)btnAction:(id)sender
{
    if (_delegate && [_delegate respondsToSelector:@selector(backActionOfDelegate)])
    {
        [_delegate backActionOfDelegate];
    }
}

-(void)setTopTitle:(NSString *)title
{
    titleLab.text = title;
}

-(void)setTopTitleColor:(UIColor *)color
{
    titleLab.textColor = color;
}

-(void)setTopTitleFont:(UIFont *)font
{
    [titleLab setFont:font];
}

-(void)setBackBtnHide:(BOOL)hide
{
    backBtn.hidden  = hide;
}

-(void)setTopBgColor:(UIColor *)backgroundColor
{
    bgView.backgroundColor = backgroundColor;
}

-(void)setBackBtnImage:(UIImage *)image
{
    [backBtn setImage:image forState:UIControlStateNormal];
}

-(void)setTopLineHide:(BOOL)hide
{
    UIView *line = [self viewWithTag:LINE];
    line.hidden = hide;
}
-(void)setTopBarHidden:(BOOL)hide
{
    self.hidden=hide;
}
@end
