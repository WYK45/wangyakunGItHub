//
//  HistoryViewController.m
//  CharacterPicker
//
//  Created by 王亚坤 on 2019/2/21.
//  Copyright © 2019 王亚坤. All rights reserved.
//

#import "HistoryViewController.h"
#import "TheResultModel.h"
@interface HistoryViewController ()

@end

@implementation HistoryViewController

-(void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];
    [self readData];
}
- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    if ([[[TheResultModel shareInstance] getPreferredLanguage] isEqualToString:@"zh-Hans-CN"]) {
        [self setTopTitle:@"识别历史"];
    }
    else
    {
        [self setTopTitle:@"OCRhistory"];
    }
    
     [self readData];
    self.tab.delegate = self;
    self.tab.dataSource = self;
    UIButton * btn = [self createBtn:CGRectMake(FitX(750-123), FitY(60), FitWidth(98), FitHeight(48)) title:@"清空" iconImage:nil backgroundImage:nil tag:8000 textColor:[UIColor whiteColor]];
    if ([[[TheResultModel shareInstance] getPreferredLanguage] isEqualToString:@"zh-Hans-CN"]) {
        [btn setTitle:@"清空" forState:UIControlStateNormal];
    }
    else
    {
        [btn setTitle:@"remove" forState:UIControlStateNormal];
    }
    [btn addTarget:self action:@selector(deleAllObjects) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:btn];
    
}
-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return _dataArray.count;
}
-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    UITableViewCell * cell = [[UITableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"cellid"];
    UILabel * lab1 = [[UILabel alloc]initWithFrame:CGRectMake(FitX(300), FitY(20), FitHeight(300),FitHeight(80))];
    lab1.font = [UIFont systemFontOfSize:FitFont(30)];
    lab1.tag = 49999;
    [cell addSubview:lab1];
    
    UILabel * lab2 = [[UILabel alloc]initWithFrame:CGRectMake(FitX(300), FitY(110), FitHeight(300),FitHeight(30))];
    lab2.font = [UIFont systemFontOfSize:FitFont(20)];
    lab1.textColor = [UIColor blueColor];
//    lab2.tag = 50009;
    [cell addSubview:lab2];
    UIImageView * ima = [[UIImageView alloc]initWithFrame:CGRectMake(FitX(20), FitY(10), FitWidth(180), FitWidth(180))];
//    ima.tag = 50019;
    [cell addSubview:ima];
    
    TheResultModel * result = (TheResultModel *)_dataArray[indexPath.row];
    
    lab1.text = result.detail;
    lab2.text = result.data;
    ima.image = result.imag;
    cell.selectionStyle = UITableViewCellSelectionStyleNone;      
    return cell;
}
-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return FitHeight(210);
}
//懒加载
-(UITableView *)tab{
    if (!_tab)
    {
        _tab = [[UITableView alloc]initWithFrame:CGRectMake(0, TopAndSystemHeight, ScreenWidth,ScreenHeight-TopAndSystemHeight-FitHeight(100)) style:UITableViewStylePlain];
        [self.view addSubview:_tab];
    }
    return _tab;
}


//数据操作
-(void)readData
{
    NSData * data1 = [[NSUserDefaults standardUserDefaults] valueForKey:@"resultModel"];
    NSArray * arr1  = [NSKeyedUnarchiver unarchiveObjectWithData:data1];
    
    NSMutableArray * array = [arr1 mutableCopy];
    _dataArray = [array copy];
    [_tab reloadData];
}
-(void)deleAllObjects
{
    
    if ([[[TheResultModel shareInstance] getPreferredLanguage] isEqualToString:@"zh-Hans-CN"]) {
        UIAlertController * alert  = [UIAlertController alertControllerWithTitle:@"确定删除所有数据？" message:nil preferredStyle:UIAlertControllerStyleAlert];
        UIAlertAction * alertAction1 = [UIAlertAction actionWithTitle:@"确定" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
            [[NSUserDefaults standardUserDefaults] removeObjectForKey:@"resultModel"];
            [self viewDidLoad];
        }];
        
        UIAlertAction * alertAction2 = [UIAlertAction actionWithTitle:@"取消" style:UIAlertActionStyleDestructive handler:nil];
        
        [alert addAction:alertAction2];
        [alert addAction:alertAction1];
        
        [self presentViewController:alert animated:YES completion:nil];
    }
    else{
        UIAlertController * alert  = [UIAlertController alertControllerWithTitle:@"Are you sure to delete all data?" message:nil preferredStyle:UIAlertControllerStyleAlert];
        UIAlertAction * alertAction1 = [UIAlertAction actionWithTitle:@"determine" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
            [[NSUserDefaults standardUserDefaults] removeObjectForKey:@"resultModel"];
            [self viewDidLoad];
        }];
        
        UIAlertAction * alertAction2 = [UIAlertAction actionWithTitle:@"cancel" style:UIAlertActionStyleDestructive handler:nil];
        
        [alert addAction:alertAction2];
        [alert addAction:alertAction1];
        
        [self presentViewController:alert animated:YES completion:nil];
    }
    
    
    
    
   
}

- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (editingStyle == UITableViewCellEditingStyleDelete) {
        
        // 删除数据源的数据,self.cellData是你自己的数据
        NSMutableArray * muArr = [self.dataArray mutableCopy];
        [muArr
         removeObjectAtIndex:indexPath.row];
        self.dataArray = [muArr copy];
        // 删除列表中数据
        [tableView deleteRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationFade];
    }
    
}
-(void)viewDidDisappear:(BOOL)animated
{
    [super viewDidDisappear:animated];
    dispatch_queue_t queue = dispatch_queue_create("net.bujige.testQueue", DISPATCH_QUEUE_CONCURRENT);
    
    dispatch_async(queue, ^{
        // 追加任务1
        [[NSUserDefaults standardUserDefaults] removeObjectForKey:@"resultModel"];
        
        NSData *data1 = [NSKeyedArchiver archivedDataWithRootObject:self.dataArray];
        
        [[NSUserDefaults standardUserDefaults] setObject:data1 forKey:@"resultModel"];
        
        
    });
}
/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
