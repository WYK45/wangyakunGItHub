//
//  MeumViewController.h
//  CharacterPicker
//
//  Created by 王亚坤 on 2019/2/19.
//  Copyright © 2019 王亚坤. All rights reserved.
//

#import "BaseViewController.h"
#import "ZZQAvatarPicker.h"
#import "TransmissionTool.h"
#import "XWSLeftView.h"
#import "XWSRightView.h"
#import "TheResultModel.h"
NS_ASSUME_NONNULL_BEGIN

@interface MeumViewController : BaseViewController<XWSLeftViewDelegate,XWSRightViewDelegate,UITableViewDataSource,UITableViewDelegate,UITextViewDelegate>

@property (nonatomic, strong) XWSLeftView *leftView;
@property (nonatomic, strong) XWSRightView *rightView;
@property (nonatomic, strong) NSMutableArray *screens;
@property (nonatomic, strong) UILabel *titleLabb;
@property (nonatomic, strong) UITableView * tab;
@property (nonatomic, strong) UITextView * textV;
@property (nonatomic, strong) UIImageView * imgV;
@property BOOL isSave;
+(MeumViewController *)shareInstance;
@end

NS_ASSUME_NONNULL_END
