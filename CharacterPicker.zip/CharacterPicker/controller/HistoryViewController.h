//
//  HistoryViewController.h
//  CharacterPicker
//
//  Created by 王亚坤 on 2019/2/21.
//  Copyright © 2019 王亚坤. All rights reserved.
//

#import "BaseViewController.h"

NS_ASSUME_NONNULL_BEGIN

@interface HistoryViewController : BaseViewController<UITableViewDelegate,UITableViewDataSource>
@property (nonatomic,strong) UITableView * tab;
@property (nonatomic,strong) NSArray * dataArray;
@end

NS_ASSUME_NONNULL_END
