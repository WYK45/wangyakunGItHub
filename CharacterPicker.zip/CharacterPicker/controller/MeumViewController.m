//
//  MeumViewController.m
//  CharacterPicker
//
//  Created by 王亚坤 on 2019/2/19.
//  Copyright © 2019 王亚坤. All rights reserved.
//

#import "MeumViewController.h"
#import "TransmissionTool.h"
#import <Social/Social.h>
@interface MeumViewController ()

@end

@implementation MeumViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    __block NSString * str = [NSString new];
    [[TransmissionTool shareInstance] getToken:^(NSString * _Nonnull Token) {
        if (![Token isEqualToString:@""])
        {
            str = Token;
            [MyProgressHUD dismiss];
        }
    }];
    
    self.textV.delegate = self;
   
    
   
    // Do any additional setup after loading the view.
//    [self setTopTitle:@"选择功能"];
    
    UIButton * btn9 = [self createBtn:CGRectMake(FitX(0), FitY(60), FitWidth(128), FitWidth(48)) title:nil iconImage:[UIImage imageNamed:@"菜单"] backgroundImage:nil tag:5000 textColor:[UIColor whiteColor]];
        [btn9 addTarget:self action:@selector(leftViewAction) forControlEvents:UIControlEventTouchUpInside];
        [self.view addSubview:btn9];
    
    [self.view addSubview:self.tab];
    if ([[[TheResultModel shareInstance] getPreferredLanguage] isEqualToString:@"zh-Hans-CN"]) {
        self.titleLabb.text = @"识别结果";
    }
    else
    {
        self.titleLabb.text = @"OCRresults";
    }
    
}

+(MeumViewController *)shareInstance
{
    static MeumViewController * singletonManager = nil;
    @synchronized(self){
        if (!singletonManager) {
            singletonManager = [[MeumViewController alloc]init];
        }
    }
    return singletonManager;
}






-(void)leftViewAction
{
    [self setUpLeftMenuView];
    self.leftView.hidden = NO;
    [UIView animateWithDuration:0.35 animations:^{
        [self.leftView mas_updateConstraints:^(MASConstraintMaker *make) {
            make.left.mas_equalTo(0);
        }];
        [[UIApplication sharedApplication].keyWindow layoutIfNeeded];
    } completion:^(BOOL finished) {
    }];
    
    //设置颜色渐变动画
    [self.leftView startCoverViewOpacityWithAlpha:0.5 withDuration:0.35];
    
}
- (void)setUpLeftMenuView{
    //获取到的个人信息
    NSString *account;
    
    if ([[[TheResultModel shareInstance] getPreferredLanguage] isEqualToString:@"zh-Hans-CN"]) {
        account = @"功能选择";
    }
    else
    {
        account = @"Select";
    }
    
    NSMutableDictionary *dic = [NSMutableDictionary dictionary];
    dic[@"account"] = account;
    dic[@"icon"] = @"left_setting";
    
    if (!_leftView) {
        _leftView = [[XWSLeftView alloc] initWithFrame:CGRectZero withUserInfo:dic];
        [UIApplication sharedApplication].keyWindow.backgroundColor = [UIColor clearColor];
        
        [[UIApplication sharedApplication].keyWindow addSubview:_leftView];
        _leftView.delegate = self;
        _leftView.hidden = YES;
        [_leftView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.bottom.top.mas_equalTo(0);
            make.left.mas_equalTo(-ScreenWidth);
            make.width.mas_equalTo(ScreenWidth);
        }];
    }
}
//收回左侧侧边栏
- (void)hideLeftMenuView{
    [self.leftView cancelCoverViewOpacity];
    [UIView animateWithDuration:0.35 animations:^{
        [self.leftView mas_updateConstraints:^(MASConstraintMaker *make) {
            make.left.mas_equalTo(-ScreenWidth);
        }];
        
        [[UIApplication sharedApplication].keyWindow layoutIfNeeded];
        
    }completion:^(BOOL finished) {
        self.leftView.hidden = YES;
    }];
}
#pragma mark - XWSLeftViewDelegate
- (void)touchLeftView:(XWSLeftView *)leftView byType:(XWSTouchItem)type{
    
    [self hideLeftMenuView];
    
    UIViewController *vc = nil;
    
    switch (type) {
        case XWSTouchItemUserInfo:
        {
            
        }
            break;
        case XWSTouchItemDevicesList:
        {
            [self handwritingAction];
        }
            break;
        case XWSTouchItemAlarm:
        {
             [self general_basicAction];
        }
            break;
        case XWSTouchItemStatistics:
        {
            [self idcardAction];
        }
            break;
        case XWSTouchItemFeedback:
        {
            [self bankcardAction];
        }
            break;
        case XWSTouchItemHelp:
        {
            [self train_ticketAction];
        }
            break;
        case XWSTouchItemScan:
        {
            [self webimageAction];
        }
            break;
        case XWSTouchItemSetting:
        {
            
            [self form_ocrAction];
        }
            break;
        case WYKTouchItemInvoice:
        {
            
            [self vat_invoiceAction];
        }
            break;
            
        default:
            break;
    }
    
    if (vc == nil) {
        return;
    }
    [self.navigationController pushViewController:vc animated:YES];
}

#pragma mark - 设置右边侧边栏
- (void)setUpRightMenuView{
    
    NSData *JSONData = [NSData dataWithContentsOfFile:[[NSBundle mainBundle] pathForResource:@"json" ofType:@"json"]];
    
    NSArray *dataArray = [NSJSONSerialization JSONObjectWithData:JSONData options:NSJSONReadingAllowFragments error:nil];
    [self.screens removeAllObjects];
    [self.screens addObjectsFromArray:dataArray];
    
    if (!_rightView) {
        _rightView = [[XWSRightView alloc] initWithFrame:CGRectZero];
        _rightView.delegate = self;
        _rightView.hidden = YES;
        [UIApplication sharedApplication].keyWindow.backgroundColor = [UIColor clearColor];
        [[UIApplication sharedApplication].keyWindow addSubview:_rightView];
        [_rightView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.bottom.top.mas_equalTo(0);
            make.left.mas_equalTo(0);
            make.right.mas_equalTo(ScreenWidth);
        }];
    }
}

- (IBAction)showRightMenuView:(id)sender {
    _rightView.datas = self.screens;
    _rightView.hidden = NO;
    [UIView animateWithDuration:0.35 animations:^{
        [self.rightView mas_updateConstraints:^(MASConstraintMaker *make) {
            make.right.mas_equalTo(0);
            make.left.mas_equalTo(-ScreenWidth);
        }];
        [[UIApplication sharedApplication].keyWindow layoutIfNeeded];
    } completion:^(BOOL finished) {
    }];
    
    //设置颜色渐变动画
    [_rightView startCoverViewOpacityWithAlpha:0.5 withDuration:0.35];
}

- (void)hideRightMenuView{
    
    //把盖板颜色的alpha值至为0
    [_rightView cancelCoverViewOpacity];
    
    //移动侧边栏回到原来的位置
    [UIView animateWithDuration:0.35 animations:^{
        [self.rightView mas_updateConstraints:^(MASConstraintMaker *make) {
            make.left.mas_equalTo(0);
            make.right.mas_equalTo(ScreenWidth);
        }];
        
        [[UIApplication sharedApplication].keyWindow layoutIfNeeded];
        
    }completion:^(BOOL finished) {
        self.rightView.hidden = YES;
    }];
}

#pragma mark - XWSRightViewDelegate
- (void)clickRightView:(XWSRightView *)rightView getLeftText:(NSString *)leftText getRightText:(NSString *)rightText{
    NSLog(@"leftText:%@ rightText:%@",leftText,rightText);
    [self hideRightMenuView];
}



#pragma mark  识别功能

-(void)handwritingAction
{
    [ZZQAvatarPicker startSelected:^(UIImage * _Nonnull image) {
        
        if (image != NULL)
        {
            self.imgV.image = image;
            [[TransmissionTool shareInstance] handwritingTextFromImage:image handler:^(NSString * _Nonnull words) {
                NSLog(@"words = %@",words);
                
                self.textV.text = words;
                self->_isSave = NO;
            }];
        }
        
        
    }];
}


-(void)general_basicAction
{
    
    [ZZQAvatarPicker startSelected:^(UIImage * _Nonnull image) {
        if (image != NULL)
        {
            self.imgV.image = image;
            [[TransmissionTool shareInstance] general_basicTextFromImage:image handler:^(NSString * _Nonnull words) {
                NSLog(@"words = %@",words);
                self.textV.text = words;
                [TheResultModel shareInstance].detail = words;
                [TheResultModel shareInstance].imag = image;
                
                //获取当前日期
                NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
                
                // ----------设置你想要的格式,hh与HH的区别:分别表示12小时制,24小时制
                
                [formatter setDateFormat:@"YYYY-MM-dd HH:mm"];
                
                //现在时间,你可以输出来看下是什么格式
                
                NSDate *datenow = [NSDate date];
                
                //----------将nsdate按formatter格式转成nsstring
                
                [TheResultModel shareInstance].data = [formatter stringFromDate:datenow];
                self->_isSave = NO;
                
            }];
        }
        
        
    }];
}

-(void)idcardAction
{
    [ZZQAvatarPicker startSelected:^(UIImage * _Nonnull image) {
        
        if (image != NULL)
        {
            self.imgV.image = image;
            [[TransmissionTool shareInstance] idcardTextFromImage:image handler:^(NSString * _Nonnull words) {
                NSLog(@"words = %@",words);
                self.textV.text = words;
                [TheResultModel shareInstance].detail = words;
                [TheResultModel shareInstance].imag = image;
                
                //获取当前日期
                NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
                
                // ----------设置你想要的格式,hh与HH的区别:分别表示12小时制,24小时制
                
                [formatter setDateFormat:@"YYYY-MM-dd HH:mm"];
                
                //现在时间,你可以输出来看下是什么格式
                
                NSDate *datenow = [NSDate date];
                
                //----------将nsdate按formatter格式转成nsstring
                
                [TheResultModel shareInstance].data = [formatter stringFromDate:datenow];
                self->_isSave = NO;
            }];
        }
        
    }];
}
-(void)bankcardAction
{
    [ZZQAvatarPicker startSelected:^(UIImage * _Nonnull image) {
        
        if (image != NULL)
        {
            self.imgV.image = image;
            [[TransmissionTool shareInstance] bankcardTextFromImage:image handler:^(NSString * _Nonnull words) {
                NSLog(@"words = %@",words);
                self.textV.text = words;
                [TheResultModel shareInstance].detail = words;
                [TheResultModel shareInstance].imag = image;
                
                //获取当前日期
                NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
                
                // ----------设置你想要的格式,hh与HH的区别:分别表示12小时制,24小时制
                
                [formatter setDateFormat:@"YYYY-MM-dd HH:mm"];
                
                //现在时间,你可以输出来看下是什么格式
                
                NSDate *datenow = [NSDate date];
                
                //----------将nsdate按formatter格式转成nsstring
                
                [TheResultModel shareInstance].data = [formatter stringFromDate:datenow];
                self->_isSave = NO;
            }];
        }
        
    }];
}
-(void)form_ocrAction
{
    [ZZQAvatarPicker startSelected:^(UIImage * _Nonnull image) {
        
        if (image != NULL)
        {
            self.imgV.image = image;
            [[TransmissionTool shareInstance] form_ocrTextFromImage:image handler:^(NSString * _Nonnull words) {
                NSLog(@"words = %@",words);
                self.textV.text = words;
                [TheResultModel shareInstance].detail = words;
                [TheResultModel shareInstance].imag = image;
                
                //获取当前日期
                NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
                
                // ----------设置你想要的格式,hh与HH的区别:分别表示12小时制,24小时制
                
                [formatter setDateFormat:@"YYYY-MM-dd HH:mm"];
                
                //现在时间,你可以输出来看下是什么格式
                
                NSDate *datenow = [NSDate date];
                
                //----------将nsdate按formatter格式转成nsstring
                
                [TheResultModel shareInstance].data = [formatter stringFromDate:datenow];
                self->_isSave = NO;
            }];
        }
       
        
        
    }];
}
-(void)train_ticketAction
{
    
    [ZZQAvatarPicker startSelected:^(UIImage * _Nonnull image) {
        if (image != NULL)
        {
            self.imgV.image = image;
            [[TransmissionTool shareInstance] train_ticketTextFromImage:image handler:^(NSString * _Nonnull words) {
                NSLog(@"words123 = %@",words);
                self.textV.text = words;
                [TheResultModel shareInstance].detail = words;
                [TheResultModel shareInstance].imag = image;
                
                //获取当前日期
                NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
                
                // ----------设置你想要的格式,hh与HH的区别:分别表示12小时制,24小时制
                
                [formatter setDateFormat:@"YYYY-MM-dd HH:mm"];
                
                //现在时间,你可以输出来看下是什么格式
                
                NSDate *datenow = [NSDate date];
                
                //----------将nsdate按formatter格式转成nsstring
                
                [TheResultModel shareInstance].data = [formatter stringFromDate:datenow];
                self->_isSave = NO;
            }];
        }
        
    }];
}
-(void)webimageAction
{
    [ZZQAvatarPicker startSelected:^(UIImage * _Nonnull image) {
        
        if (image != NULL)
        {
            self.imgV.image = image;
            [[TransmissionTool shareInstance] webimageTextFromImage:image handler:^(NSString * _Nonnull words) {
                NSLog(@"words = %@",words);
                self.textV.text = words;
                [TheResultModel shareInstance].detail = words;
                [TheResultModel shareInstance].imag = image;
                
                //获取当前日期
                NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
                
                // ----------设置你想要的格式,hh与HH的区别:分别表示12小时制,24小时制
                
                [formatter setDateFormat:@"YYYY-MM-dd HH:mm"];
                
                //现在时间,你可以输出来看下是什么格式
                
                NSDate *datenow = [NSDate date];
                
                //----------将nsdate按formatter格式转成nsstring
                
                [TheResultModel shareInstance].data = [formatter stringFromDate:datenow];
                self->_isSave = NO;
            }];
        }
        
        
        
    }];
}
-(void)vat_invoiceAction
{
    [ZZQAvatarPicker startSelected:^(UIImage * _Nonnull image) {
        
        if (image != NULL)
        {
            self.imgV.image = image;
            [[TransmissionTool shareInstance] vat_invoiceTextFromImage:image handler:^(NSString * _Nonnull words) {
                NSLog(@"words = %@",words);
                self.textV.text = words;
                [TheResultModel shareInstance].detail = words;
                [TheResultModel shareInstance].imag = image;
                
                //获取当前日期
                NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
                
                // ----------设置你想要的格式,hh与HH的区别:分别表示12小时制,24小时制
                
                [formatter setDateFormat:@"YYYY-MM-dd HH:mm"];
                
                //现在时间,你可以输出来看下是什么格式
                
                NSDate *datenow = [NSDate date];
                
                //----------将nsdate按formatter格式转成nsstring
                
                [TheResultModel shareInstance].data = [formatter stringFromDate:datenow];
                self->_isSave = NO;
            }];
        }
    }];
}
/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/
-(UILabel *)titleLabb
{
    if (_titleLabb == nil)
    {
        _titleLabb = [[UILabel alloc] initWithFrame:CGRectMake(50, FitY(60), ScreenWidth-100, 20)];
        _titleLabb.textColor = [UIColor blackColor];
        _titleLabb.textAlignment = NSTextAlignmentCenter;
        _titleLabb.backgroundColor = [UIColor clearColor];
        _titleLabb.font = [UIFont systemFontOfSize:17.0];
        [self.view addSubview:_titleLabb];
    }
    return _titleLabb;
}
#pragma mark tableViewDelegate
//懒加载
-(UIImageView *)imgV
{
    if (!_imgV)
    {
        _imgV = [[UIImageView alloc]initWithFrame:CGRectMake(FitX(20), FitY(20), FitWidth(710), FitHeight(750))];
        if ([[[TheResultModel shareInstance] getPreferredLanguage] isEqualToString:@"zh-Hans-CN"]) {
            _imgV.image = [UIImage imageNamed:@"组2_33"];
        }
        else
        {
            _imgV.image = [UIImage imageNamed:@"组3_76"];
        }
        
    }
    return _imgV;
}
-(UITextView *)textV
{
    if (!_textV)
    {
        _textV = [[UITextView alloc]initWithFrame:CGRectMake(FitX(20), FitY(790), FitWidth(710), FitHeight(750)/2.5)];
        _textV.layer.borderWidth = 1.0f;
        _textV.layer.borderColor = [UIColor grayColor].CGColor;
    }
    
    return _textV;
}
-(UITableView *)tab
{
    if (_tab == nil)
    {
        _tab = [[UITableView alloc]initWithFrame:CGRectMake(FitX(0), TopAndSystemHeight, ScreenWidth, ScreenHeight-TopAndSystemHeight-FitHeight(100)) style:UITableViewStylePlain];
        _tab.delegate = self;
        _tab.dataSource = self;
    }
    return _tab;
}
-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return 1;
}
-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    UITableViewCell * cell = [tableView dequeueReusableCellWithIdentifier:@"cellid"];
    if (!cell)
    {
        cell = [[UITableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"cellid"];
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
        [cell addSubview:self.textV];
        [cell addSubview:self.imgV];
        
        
        
      //分享按钮
        
        UIButton * btn1 = [self createBtn:CGRectMake(ScreenWidth/2+FitX(20), TopAndSystemHeight+FitY(1000), ScreenWidth/2-FitX(40), FitHeight(80)) title:@"分享识别结果" iconImage:nil backgroundImage:nil tag:6000 textColor:[UIColor blackColor]];
        btn1.layer.cornerRadius = 5.0f;
        btn1.layer.borderWidth = 1.0f;
        
        if ([[[TheResultModel shareInstance] getPreferredLanguage] isEqualToString:@"zh-Hans-CN"]) {
            [btn1 setTitle:@"分享识别结果" forState:UIControlStateNormal];
        }
        else
        {
            [btn1 setTitle:@"ShareResults" forState:UIControlStateNormal];
        }
        
        btn1.layer.borderColor = [UIColor colorWithRed:0 green:168/255.0 blue:246/255.0 alpha:1.0].CGColor;
        [btn1 setTitleColor:[UIColor colorWithRed:0 green:168/255.0 blue:246/255.0 alpha:1.0] forState:UIControlStateNormal];
        [btn1 setBackgroundColor:[UIColor whiteColor]];
//
        btn1.titleLabel.font = [UIFont systemFontOfSize:FitFont(30)];
        [btn1 addTarget:self action:@selector(shareAction) forControlEvents:UIControlEventTouchUpInside];
        [cell addSubview:btn1];
        
        
        UIButton * btn = [self createBtn:CGRectMake(FitX(20), TopAndSystemHeight+FitY(1000), ScreenWidth/2-FitX(40), FitHeight(80)) title:@"拷贝文字到粘贴板" iconImage:nil backgroundImage:nil tag:6000 textColor:[UIColor blackColor]];
        
        if ([[[TheResultModel shareInstance] getPreferredLanguage] isEqualToString:@"zh-Hans-CN"]) {
            [btn setTitle:@"拷贝文字到粘贴板" forState:UIControlStateNormal];
        }
        else
        {
            [btn setTitle:@"CopyTheResult" forState:UIControlStateNormal];
        }
        
        btn.layer.cornerRadius = 5.0f;
        [btn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
        [btn setBackgroundColor:[UIColor colorWithRed:0 green:168/255.0 blue:246/255.0 alpha:1.0]];
        btn.titleLabel.font = [UIFont systemFontOfSize:FitFont(30)];
        [btn addTarget:self action:@selector(SaveAction) forControlEvents:UIControlEventTouchUpInside];
        [cell addSubview:btn];
        
    }
    return cell;
}
-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
//    return (ScreenHeight-TopAndSystemHeight-FitHeight(100))*1.3;
    return (self.textV.frame.size.height+self.imgV.frame.size.height+FitHeight(600));
}

-(void)SaveAction
{
    if (self.imgV.image == NULL && self.textV.text == nil) {
        return;
    }
    
    
    UIPasteboard*pasteboard = [UIPasteboard generalPasteboard];
    pasteboard.string=self.textV.text;
    if ([[[TheResultModel shareInstance] getPreferredLanguage] isEqualToString:@"zh-Hans-CN"]) {
        [MyProgressHUD showSuccessWithStatus:@"拷贝成功" duration:2.0f];
    }
    else{
        [MyProgressHUD showSuccessWithStatus:@"successful" duration:2.0f];
    }
    // 读数据
    NSData * data1 = [[NSUserDefaults standardUserDefaults] valueForKey:@"resultModel"];
    NSArray * arr1  = [NSKeyedUnarchiver unarchiveObjectWithData:data1];
    NSLog(@"arr1 = %@",arr1);
    NSMutableArray * array = [arr1 mutableCopy];
    if (array == NULL)
    {
        array = [[NSMutableArray alloc]init];
    }
    
    if([self.textV.text isEqualToString:[TheResultModel shareInstance].detail])
    {
        NSLog(@"123");
        if (!_isSave)
        {
            NSLog(@"456");
            [array addObject:[TheResultModel shareInstance]];
            NSArray * arr0 = [array copy];
            //存多个自定义对象。方法与存单个相同，但是要把对象放到数组里面然后在存进去
            //存数据
            NSData *data1 = [NSKeyedArchiver archivedDataWithRootObject:arr0];//dataArray里面存的是MPMusicInfoModel类的对象。
            NSUserDefaults *userDetaults = [NSUserDefaults standardUserDefaults];
            [userDetaults setObject:data1 forKey:@"resultModel"];
            [userDetaults synchronize];
        }
        
        _isSave = YES;
    }
    else
    {
        NSLog(@"789");
        [TheResultModel shareInstance].detail = self.textV.text;
        
        [array removeLastObject];
        [array addObject:[TheResultModel shareInstance]];
        NSArray * arr0 = [array copy];
        //存多个自定义对象。方法与存单个相同，但是要把对象放到数组里面然后在存进去
        //存数据
        NSData *data1 = [NSKeyedArchiver archivedDataWithRootObject:arr0];//dataArray里面存的是MPMusicInfoModel类的对象。
        NSUserDefaults *userDetaults = [NSUserDefaults standardUserDefaults];
        [userDetaults setObject:data1 forKey:@"resultModel"];
        [userDetaults synchronize];
    }
//    self.imgV.image = [TheResultModel shareInstance].imag;
}
-(void)shareAction
{
    
    NSArray *activityItems = @[self.textV.text];
    UIActivityViewController *activityVC = [[UIActivityViewController alloc]initWithActivityItems:activityItems applicationActivities:nil];
    
    [self presentViewController:activityVC animated:YES completion:nil];

    
}


-(void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event
{
    [[[UIApplication sharedApplication] keyWindow] endEditing:YES];
}

//回车键退出键盘

-(BOOL)textView:(UITextView *)textView shouldChangeTextInRange:(NSRange)range replacementText:(NSString *)text
{
    if ([text isEqualToString:@"\n"])
    {
        [textView resignFirstResponder];
        return NO;
    }
    return YES;
}

@end
